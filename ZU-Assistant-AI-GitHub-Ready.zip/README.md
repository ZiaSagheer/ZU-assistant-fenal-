# ZU Assistant AI (زیڈ یو اسسٹنٹ)

**ZU Assistant** is a premium, intelligent, native Android personal assistant designed with futuristic visuals (Deep Black, Midnight Blue, Elegant Violet, Neon Cyan accents), advanced voice interactions, robust device controls, local productivity tools, and full trilingual capabilities (**Urdu script, Roman Urdu, and English**).

---

## 🌟 Key Features

### 1. Trilingual Voice & AI Assistant
- **Automatic Language Detection:** Seamlessly understands Urdu script (`اردو`), Roman Urdu (`"kya haal hai"`), and English.
- **Natural Conversational Intelligence:** Powered by Google Gemini AI with streaming response capability, context-aware multi-turn history, stop-generation control, and response regeneration.
- **RTL Urdu Script Support:** Native right-to-left alignment, tailored line-heights, and clear fonts for Urdu rendering alongside English markdown and syntax-highlighted code blocks with one-tap copy.
- **Hands-Free Voice Interaction:** Android `SpeechRecognizer` (`ur-PK` / `en-US`) and `TextToSpeech` with real-time volume reactivity (RMS dB audio wave pulse), configurable speaking speed and pitch, and tap-to-interrupt voice playback.
- **Text Input Fallback:** Immediate keyboard fallback when microphone is restricted or muted.

### 2. Smart Android Device Controls
- **Flashlight (Torch):** Safe on/off toggle via Android `CameraManager` (`"Torch on karo"`, `"ٹارچ بند کرو"`).
- **Battery & Charging Telemetry:** Real-time percentage and charging status check (`"Battery kitni hai?"`, `"بیٹری چیک کرو"`).
- **System Date & Time:** Formatted in Urdu and English (`"Aaj kya date hai?"`, `"وقت کیا ہوا"`).
- **Quick Settings Shortcuts:** Direct links to Android Wi-Fi, Bluetooth, Display, and Sound settings screens.
- **App Launchers:** One-tap and voice launching for WhatsApp, YouTube, Camera, Phone Dialer, and Browser.
- **Alarms & Timers:** Native integration with Android `AlarmClock` intents.

### 3. WhatsApp Smart Messaging Assistant
- Enter recipient numbers with international country codes (e.g. `+923001234567`).
- Draft messages in Urdu, Roman Urdu, or English.
- **Zero-Accident Safety:** Displays complete draft in a review dialog before opening WhatsApp. Never sends messages automatically without explicit user confirmation.

### 4. Personal Productivity Tools
- **Room SQLite Local Storage:** Offline, durable Notes & To-Do lists with search, tags, completion toggles, and copy actions.
- **Quick Calculator:** Fast arithmetic expression evaluator (`"50 * 4"`, `"100 plus 25"`) plus an interactive on-screen keypad.
- **Unit Converter:** Real-time conversion across Length (m, km, ft, mi, in), Weight (kg, lbs, g, oz), and Temperature (°C, °F).
- **AI Assist Tools:** One-tap Text Summarizer, Urdu-English Translator, and Social Media Caption Generator.

### 5. Configurable AI & Offline Safety
- **Provider Settings:** Choose between `gemini-2.5-flash`, `gemini-1.5-flash`, `gemini-2.0-flash`, and `gemini-2.5-pro`.
- **API Key Security:** Inject via AI Studio Secrets (`GEMINI_API_KEY`) or customize via in-app Settings.
- **Full Offline Fallback:** Device controls, calculations, notes, battery, and date/time commands execute 100% on-device even when offline.

---

## 🛠️ Architecture & Tech Stack

- **Language:** Kotlin 2.2.10
- **UI Framework:** Jetpack Compose with Material Design 3 (M3)
- **Architecture Pattern:** MVVM (Model-View-ViewModel) with Clean Architecture separation
- **Local Persistence:** Android Jetpack Room Database (SQLite)
- **Networking:** OkHttp & Retrofit with Server-Sent Events (SSE) streaming
- **Voice Stack:** Android `SpeechRecognizer`, `TextToSpeech`, and dynamic `Canvas` audio wave visualization
- **Security:** Android Secrets Gradle Plugin, App Check attestation, Zero-Trust untrusted intent validation

---

## 🚀 Building & Running

### Prerequisites
- Android Studio Ladybug / Meerkat (or newer)
- Android SDK 34 / 36
- JDK 17 or 21

### Running Tests
Execute JVM unit and Robolectric tests:
```bash
gradle :app:testDebugUnitTest
```

### Building Debug APK
```bash
gradle :app:assembleDebug
```
The generated APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

### Generating a Signed Release APK
Configure your keystore in `app/build.gradle.kts` and environment variables (`KEYSTORE_PATH`, `STORE_PASSWORD`, `KEY_PASSWORD`):
```bash
gradle :app:assembleRelease
```

---

## 🔒 Permissions & Privacy
- `RECORD_AUDIO`: Voice speech-to-text recognition.
- `CAMERA`: Hardware flashlight control (no camera frames are captured or saved).
- `INTERNET` & `ACCESS_NETWORK_STATE`: AI streaming and connectivity checks.
- `VIBRATE`: Tactile haptic feedback on voice orb taps.
- `SET_ALARM`: Scheduling alarms via the native Android Clock application.

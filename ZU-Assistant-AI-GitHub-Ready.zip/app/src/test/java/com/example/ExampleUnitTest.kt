package com.example

import org.junit.Assert.*
import org.junit.Test

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testLanguageDetectionUrduScript() {
    val urduText = "السلام علیکم، آپ کا کیا نام ہے؟"
    val count = urduText.count { char ->
      char in '\u0600'..'\u06FF' || char in '\u0750'..'\u077F' || char in '\uFB50'..'\uFDFF'
    }
    assertTrue(count > 0)
  }

  @Test
  fun testMathSanitization() {
    val mathExpr = "50 * 4"
    val parts = mathExpr.split(" ")
    assertEquals(3, parts.size)
    val res = parts[0].toDouble() * parts[2].toDouble()
    assertEquals(200.0, res, 0.001)
  }

  @Test
  fun testVoiceConstantsAndStates() {
    assertEquals("ur-PK", com.example.voice.VoiceAssistantManager.LANG_URDU)
    assertEquals("en-US", com.example.voice.VoiceAssistantManager.LANG_ENGLISH)
    assertEquals("auto", com.example.voice.VoiceAssistantManager.LANG_AUTO)

    val listeningState = com.example.voice.VoiceState.Listening(language = "ur-PK", partialTranscript = "ٹارچ آن کرو")
    assertEquals("ur-PK", listeningState.language)
    assertEquals("ٹارچ آن کرو", listeningState.partialTranscript)
  }
}

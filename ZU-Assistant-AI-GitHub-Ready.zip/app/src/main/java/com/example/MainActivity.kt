package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.firebase.configureAppCheck
import com.example.ui.MainViewModel
import com.example.ui.ScreenDestination
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DeviceToolsScreen
import com.example.ui.screens.OnboardingDialog
import com.example.ui.screens.ProductivityScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.VoiceAssistantScreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.PrimaryNeonGradient
import com.example.ui.theme.VioletNeon
import com.example.ui.theme.VioletPrimary
import com.example.ui.theme.ZuAssistantTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure App Check with launch intent (safely handles environments without Firebase backend)
        try {
            configureAppCheck(this, intent)
        } catch (e: Exception) {
            android.util.Log.d("MainActivity", "AppCheck skipped: ${e.message}")
        }

        enableEdgeToEdge()

        setContent {
            val darkMode by viewModel.userPreferences.darkMode.collectAsState()
            val currentScreen by viewModel.currentScreen.collectAsState()
            val onboardingCompleted by viewModel.userPreferences.onboardingCompleted.collectAsState()

            var showOnboarding by remember { mutableStateOf(!onboardingCompleted) }

            // Permission launcher
            val permissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestMultiplePermissions()
            ) { /* results handled gracefully */ }

            fun requestAppPermissions() {
                val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    permissions.add(Manifest.permission.POST_NOTIFICATIONS)
                }
                permissionLauncher.launch(permissions.toTypedArray())
            }

            // Sub-screen BackHandler: Pop back to Dashboard
            BackHandler(enabled = currentScreen != ScreenDestination.DASHBOARD) {
                viewModel.navigateTo(ScreenDestination.DASHBOARD)
            }

            ZuAssistantTheme(darkTheme = darkMode) {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding(),
                    bottomBar = {
                        // Show bottom nav on all screens except full-screen immersive Voice Assistant
                        if (currentScreen != ScreenDestination.VOICE_ASSISTANT) {
                            ZuBottomNavigationBar(
                                currentScreen = currentScreen,
                                onNavigate = { viewModel.navigateTo(it) }
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        Crossfade(targetState = currentScreen, label = "screen_transition") { screen ->
                            when (screen) {
                                ScreenDestination.DASHBOARD -> DashboardScreen(viewModel = viewModel)
                                ScreenDestination.VOICE_ASSISTANT -> VoiceAssistantScreen(viewModel = viewModel)
                                ScreenDestination.CHAT -> ChatScreen(viewModel = viewModel)
                                ScreenDestination.DEVICE_TOOLS -> DeviceToolsScreen(viewModel = viewModel)
                                ScreenDestination.PRODUCTIVITY -> ProductivityScreen(viewModel = viewModel)
                                ScreenDestination.SETTINGS -> SettingsScreen(viewModel = viewModel)
                            }
                        }

                        if (showOnboarding) {
                            OnboardingDialog(
                                onDismiss = {
                                    showOnboarding = false
                                    viewModel.userPreferences.setOnboardingCompleted(true)
                                },
                                onRequestPermissions = {
                                    requestAppPermissions()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ZuBottomNavigationBar(
    currentScreen: ScreenDestination,
    onNavigate: (ScreenDestination) -> Unit
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        modifier = Modifier.testTag("main_bottom_nav")
    ) {
        NavigationBarItem(
            selected = currentScreen == ScreenDestination.DASHBOARD,
            onClick = { onNavigate(ScreenDestination.DASHBOARD) },
            icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
            label = { Text("Home", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CyanAccent,
                indicatorColor = VioletPrimary.copy(alpha = 0.25f)
            ),
            modifier = Modifier.testTag("nav_home")
        )

        NavigationBarItem(
            selected = currentScreen == ScreenDestination.CHAT,
            onClick = { onNavigate(ScreenDestination.CHAT) },
            icon = { Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = "Chat") },
            label = { Text("Chat", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CyanAccent,
                indicatorColor = VioletPrimary.copy(alpha = 0.25f)
            ),
            modifier = Modifier.testTag("nav_chat")
        )

        // Center Voice Assistant Orb Highlight Button
        NavigationBarItem(
            selected = currentScreen == ScreenDestination.VOICE_ASSISTANT,
            onClick = { onNavigate(ScreenDestination.VOICE_ASSISTANT) },
            icon = {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(PrimaryNeonGradient),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Voice Assistant",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            },
            label = { Text("Voice", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
            modifier = Modifier.testTag("nav_voice")
        )

        NavigationBarItem(
            selected = currentScreen == ScreenDestination.DEVICE_TOOLS,
            onClick = { onNavigate(ScreenDestination.DEVICE_TOOLS) },
            icon = { Icon(Icons.Default.Build, contentDescription = "Tools") },
            label = { Text("Tools", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CyanAccent,
                indicatorColor = VioletPrimary.copy(alpha = 0.25f)
            ),
            modifier = Modifier.testTag("nav_tools")
        )

        NavigationBarItem(
            selected = currentScreen == ScreenDestination.PRODUCTIVITY,
            onClick = { onNavigate(ScreenDestination.PRODUCTIVITY) },
            icon = { Icon(Icons.Default.EditNote, contentDescription = "Notes") },
            label = { Text("Notes", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CyanAccent,
                indicatorColor = VioletPrimary.copy(alpha = 0.25f)
            ),
            modifier = Modifier.testTag("nav_notes")
        )

        NavigationBarItem(
            selected = currentScreen == ScreenDestination.SETTINGS,
            onClick = { onNavigate(ScreenDestination.SETTINGS) },
            icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
            label = { Text("Settings", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CyanAccent,
                indicatorColor = VioletPrimary.copy(alpha = 0.25f)
            ),
            modifier = Modifier.testTag("nav_settings")
        )
    }
}

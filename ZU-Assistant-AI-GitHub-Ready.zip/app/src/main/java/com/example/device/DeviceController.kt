package com.example.device

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.Settings
import android.util.Log
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DeviceController(private val context: Context) {

    companion object {
        private const val TAG = "DeviceController"
    }

    private val cameraManager: CameraManager? by lazy {
        context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
    }

    private var isTorchOn = false

    /**
     * Toggles the device flashlight / torch.
     * Returns a pair of (Boolean success, String feedbackMessage)
     */
    fun toggleTorch(enable: Boolean? = null): Pair<Boolean, String> {
        val cm = cameraManager ?: return Pair(false, "Flashlight is not available on this device.")
        return try {
            val cameraId = cm.cameraIdList.firstOrNull { id ->
                val chars = cm.getCameraCharacteristics(id)
                val flashAvailable = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) ?: false
                val facing = chars.get(CameraCharacteristics.LENS_FACING)
                flashAvailable && facing == CameraCharacteristics.LENS_FACING_BACK
            } ?: cm.cameraIdList.firstOrNull()

            if (cameraId == null) {
                return Pair(false, "No camera with flash unit found / کیمرہ فلیش دستیاب نہیں ہے۔")
            }

            val targetState = enable ?: !isTorchOn
            cm.setTorchMode(cameraId, targetState)
            isTorchOn = targetState

            if (targetState) {
                Pair(true, "Flashlight turned ON / ٹارچ آن کر دی گئی ہے۔")
            } else {
                Pair(true, "Flashlight turned OFF / ٹارچ بند کر دی گئی ہے۔")
            }
        } catch (e: CameraAccessException) {
            Log.e(TAG, "CameraAccessException while toggling torch", e)
            Pair(false, "Camera is busy or access restricted: ${e.message}")
        } catch (e: Exception) {
            Log.e(TAG, "Error toggling torch", e)
            Pair(false, "Could not control flashlight: ${e.localizedMessage}")
        }
    }

    fun isTorchActive(): Boolean = isTorchOn

    /**
     * Queries battery level and charging status
     */
    fun getBatteryStatus(): BatteryInfo {
        val batteryIntent = context.registerReceiver(
            null,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        )
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1

        val percentage = if (level >= 0 && scale > 0) {
            (level * 100 / scale)
        } else {
            0
        }

        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

        val descriptionEnglish = "Battery is at $percentage% and ${if (isCharging) "charging ⚡" else "not charging"}."
        val descriptionUrdu = "بیٹری $percentage فیصد ہے اور ${if (isCharging) "چارج ہو رہی ہے ⚡" else "چارج نہیں ہو رہی"}۔"

        return BatteryInfo(
            percentage = percentage,
            isCharging = isCharging,
            descriptionEnglish = descriptionEnglish,
            descriptionUrdu = descriptionUrdu
        )
    }

    /**
     * Returns current formatted date & time in English and Urdu
     */
    fun getCurrentDateTime(): DateTimeInfo {
        val now = Date()
        val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
        val dateFormat = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault())

        val timeStr = timeFormat.format(now)
        val dateStr = dateFormat.format(now)

        return DateTimeInfo(
            time = timeStr,
            date = dateStr,
            formattedEnglish = "The current time is $timeStr on $dateStr.",
            formattedUrdu = "اس وقت $timeStr بج رہے ہیں اور آج $dateStr ہے۔"
        )
    }

    /**
     * Check network connectivity
     */
    fun isNetworkAvailable(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /**
     * Open installed apps safely
     */
    fun openApp(packageName: String): Pair<Boolean, String> {
        return try {
            val pm = context.packageManager
            val intent = pm.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                Pair(true, "App opened successfully.")
            } else {
                Pair(false, "Application is not installed on this device.")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error opening app $packageName", e)
            Pair(false, "Could not open app: ${e.localizedMessage}")
        }
    }

    /**
     * Open WhatsApp with prepared message for user confirmation
     */
    fun prepareWhatsAppDraft(phoneNumber: String, messageText: String): Pair<Boolean, String> {
        return try {
            val cleanedNumber = phoneNumber.replace(Regex("[^0-9+]"), "").trim()
            val encodedMessage = URLEncoder.encode(messageText, "UTF-8")
            val uriString = if (cleanedNumber.isNotEmpty()) {
                val formattedNumber = if (cleanedNumber.startsWith("+")) cleanedNumber.substring(1) else cleanedNumber
                "https://api.whatsapp.com/send?phone=$formattedNumber&text=$encodedMessage"
            } else {
                "https://api.whatsapp.com/send?text=$encodedMessage"
            }

            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uriString)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                setPackage("com.whatsapp")
            }

            val pm = context.packageManager
            if (intent.resolveActivity(pm) != null) {
                context.startActivity(intent)
                Pair(true, "Opening WhatsApp for your review and send confirmation.")
            } else {
                // Try fallback to browser link
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(uriString)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(browserIntent)
                Pair(true, "Opening WhatsApp link in browser.")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error drafting WhatsApp message", e)
            Pair(false, "Could not launch WhatsApp: ${e.localizedMessage}")
        }
    }

    /**
     * System Settings shortcuts
     */
    fun openSettings(action: String): Pair<Boolean, String> {
        return try {
            val intent = Intent(action).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Pair(true, "Opening settings.")
        } catch (e: Exception) {
            Log.e(TAG, "Error opening settings $action", e)
            Pair(false, "Unable to open system settings: ${e.localizedMessage}")
        }
    }

    /**
     * Set Alarm using Android AlarmClock intent
     */
    fun setAlarm(hour: Int, minutes: Int, message: String): Pair<Boolean, String> {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minutes)
                putExtra(AlarmClock.EXTRA_MESSAGE, message)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
                Pair(true, "Alarm set for %02d:%02d: $message".format(hour, minutes))
            } else {
                Pair(false, "No alarm application found on device.")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error setting alarm", e)
            Pair(false, "Could not set alarm: ${e.localizedMessage}")
        }
    }

    /**
     * Set Countdown Timer using Android AlarmClock intent
     */
    fun setTimer(seconds: Int, message: String): Pair<Boolean, String> {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                putExtra(AlarmClock.EXTRA_MESSAGE, message)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
                Pair(true, "Timer set for $seconds seconds: $message")
            } else {
                Pair(false, "No timer application found on device.")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error setting timer", e)
            Pair(false, "Could not set timer: ${e.localizedMessage}")
        }
    }

    /**
     * Share text for ZU Assistant
     */
    val appShareText: String
        get() = """
🌟 ZU Assistant AI (زیڈ یو اسسٹنٹ) 🌟
جدید اور ذہین ترین پرسنل اینڈرائیڈ اسسٹنٹ!
• اردو اور رومن اردو وائس سپورٹ (Urdu Voice Assistant)
• ڈیوائس کنٹرولز: ٹارچ آن/آف، بیٹری لیول، الارم، سسٹم ترتیبات
• واٹس ایپ سمارٹ میسجنگ، نوٹس، کیلکولیٹر اور AI سوال و جواب

📲 ایپ ڈاؤنلوڈ یا ٹیسٹ کرنے کے لیے لنک:
https://ais-pre-73gkagjdnmc72j3kl6km7c-989663348920.asia-east1.run.app
        """.trimIndent()

    /**
     * Share the app across any platform (WhatsApp, Telegram, SMS, etc.)
     */
    fun shareApp(targetPackage: String? = null): Pair<Boolean, String> {
        return try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "ZU Assistant AI")
                putExtra(Intent.EXTRA_TEXT, appShareText)
                if (!targetPackage.isNullOrEmpty()) {
                    setPackage(targetPackage)
                }
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            if (!targetPackage.isNullOrEmpty()) {
                val pm = context.packageManager
                if (intent.resolveActivity(pm) != null) {
                    context.startActivity(intent)
                    return Pair(true, "Opening app to share.")
                }
            }

            // General Chooser for all platforms
            val generalIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "ZU Assistant AI")
                putExtra(Intent.EXTRA_TEXT, appShareText)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooser = Intent.createChooser(generalIntent, "Share ZU Assistant via").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
            Pair(true, "Opening share menu / شیئر مینیو کھل گیا")
        } catch (e: Exception) {
            Log.e(TAG, "Error sharing app", e)
            Pair(false, "Could not open share menu: ${e.localizedMessage}")
        }
    }
}

data class BatteryInfo(
    val percentage: Int,
    val isCharging: Boolean,
    val descriptionEnglish: String,
    val descriptionUrdu: String
)

data class DateTimeInfo(
    val time: String,
    val date: String,
    val formattedEnglish: String,
    val formattedUrdu: String
)

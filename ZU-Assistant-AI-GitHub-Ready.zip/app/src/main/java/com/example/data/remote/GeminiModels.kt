package com.example.data.remote

data class GeminiPart(
    val text: String
)

data class GeminiContent(
    val role: String, // "user" or "model"
    val parts: List<GeminiPart>
)

data class GeminiRequest(
    val contents: List<GeminiContent>,
    val systemInstruction: GeminiContent? = null,
    val temperature: Float = 0.7f
)

data class GeminiResponse(
    val text: String?,
    val error: String? = null
)

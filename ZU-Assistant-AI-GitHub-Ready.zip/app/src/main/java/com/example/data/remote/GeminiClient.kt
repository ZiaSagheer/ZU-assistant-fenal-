package com.example.data.remote

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

class GeminiClient(
    private val apiKeyProvider: () -> String,
    private val modelProvider: () -> String
) {
    companion object {
        private const val TAG = "GeminiClient"
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"

        const val SYSTEM_INSTRUCTION = """
You are ZU Assistant (زیڈ یو اسسٹنٹ), a premium, intelligent, polite, culturally respectful, and highly capable Android AI personal assistant.
Your capabilities:
1. Multilingual mastery: Urdu script (اردو), Roman Urdu, and English.
2. Language mirroring:
   - When the user asks in Urdu script (e.g. السلام علیکم، آپ کون ہیں؟), answer in fluent, respectful, natural Urdu script.
   - When the user asks in Roman Urdu (e.g. "kya haal hai", "mujhe ek achi poetry sunao", "mere liye text likho"), answer in friendly and natural Roman Urdu.
   - When the user asks in English, answer in clear, polished, structured English.
3. Formatting: Use Markdown headers, bullet points, clean paragraphs, and code blocks with syntax tags. Keep responses concise, helpful, and pleasant.
4. Assistant identity: You are ZU Assistant, created to empower users on Android with voice, AI knowledge, device control assistance, and productivity.
"""
    }

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    fun getEffectiveApiKey(): String {
        val customKey = apiKeyProvider().trim()
        if (customKey.isNotEmpty()) {
            return customKey
        }
        val buildKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (_: Exception) {
            ""
        }
        return buildKey.trim()
    }

    fun isConfigured(): Boolean {
        val key = getEffectiveApiKey()
        return key.isNotEmpty() && !key.equals("MY_GEMINI_API_KEY", ignoreCase = true)
    }

    /**
     * Streams content generation chunks as a Kotlin Flow
     */
    fun streamGenerateContent(
        history: List<GeminiContent>,
        currentPrompt: String
    ): Flow<String> = flow {
        val apiKey = getEffectiveApiKey()
        if (!isConfigured()) {
            emit("⚠️ API Key not configured. Please enter your Gemini API key in Settings to chat with ZU Assistant.\n\nترتیبات (Settings) میں جاکر جیمنائی API Key داخل کریں۔ تب تک آپ تمام ڈیوائس ٹولز (ٹارچ، بیٹری، واٹس ایپ، نوٹس) استعمال کر سکتے ہیں۔")
            return@flow
        }

        val model = modelProvider().ifEmpty { "gemini-2.5-flash" }
        val endpoint = "$BASE_URL/$model:streamGenerateContent?alt=sse&key=$apiKey"

        val requestBodyJson = buildRequestBody(history, currentPrompt)
        val body = requestBodyJson.toString().toRequestBody("application/json".toMediaType())

        val request = Request.Builder()
            .url(endpoint)
            .post(body)
            .addHeader("Content-Type", "application/json")
            .build()

        try {
            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                val errorBody = response.body?.string().orEmpty()
                Log.e(TAG, "Gemini API error code: ${response.code}, body: $errorBody")
                val parsedError = parseErrorMessage(errorBody, response.code)
                emit("❌ $parsedError")
                return@flow
            }

            val inputStream = response.body?.byteStream() ?: run {
                emit("❌ Empty response from AI server.")
                return@flow
            }

            val reader = BufferedReader(InputStreamReader(inputStream))
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                val currentLine = line ?: continue
                if (currentLine.startsWith("data: ")) {
                    val jsonStr = currentLine.removePrefix("data: ").trim()
                    if (jsonStr.isEmpty() || jsonStr == "[DONE]") continue
                    try {
                        val rootObj = JSONObject(jsonStr)
                        val textChunk = extractCandidateText(rootObj)
                        if (textChunk.isNotEmpty()) {
                            emit(textChunk)
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "Failed to parse SSE JSON chunk: $jsonStr", e)
                    }
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Error in streamGenerateContent", e)
            emit("\n[Connection error: ${e.localizedMessage ?: "Network failed"}]")
        }
    }.flowOn(Dispatchers.IO)

    /**
     * Unary single-shot generation
     */
    suspend fun generateContent(
        history: List<GeminiContent>,
        currentPrompt: String
    ): GeminiResponse = withContext(Dispatchers.IO) {
        val apiKey = getEffectiveApiKey()
        if (!isConfigured()) {
            return@withContext GeminiResponse(
                text = null,
                error = "API key not configured. Please add your Gemini API key in Settings or AI Studio Secrets."
            )
        }

        val model = modelProvider().ifEmpty { "gemini-2.5-flash" }
        val endpoint = "$BASE_URL/$model:generateContent?key=$apiKey"

        val requestBodyJson = buildRequestBody(history, currentPrompt)
        val body = requestBodyJson.toString().toRequestBody("application/json".toMediaType())

        val request = Request.Builder()
            .url(endpoint)
            .post(body)
            .addHeader("Content-Type", "application/json")
            .build()

        try {
            val response = httpClient.newCall(request).execute()
            val responseString = response.body?.string().orEmpty()

            if (!response.isSuccessful) {
                Log.e(TAG, "Gemini API error: ${response.code} $responseString")
                return@withContext GeminiResponse(
                    text = null,
                    error = parseErrorMessage(responseString, response.code)
                )
            }

            val rootObj = JSONObject(responseString)
            val text = extractCandidateText(rootObj)
            if (text.isNotEmpty()) {
                GeminiResponse(text = text)
            } else {
                GeminiResponse(text = null, error = "Received empty response from AI model.")
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Failed unary generateContent", e)
            GeminiResponse(text = null, error = e.localizedMessage ?: "Network connection error")
        }
    }

    private fun buildRequestBody(history: List<GeminiContent>, currentPrompt: String): JSONObject {
        val root = JSONObject()
        val contentsArray = JSONArray()

        // Multi-turn history
        for (item in history) {
            val contentObj = JSONObject()
            contentObj.put("role", item.role)
            val partsArr = JSONArray()
            for (p in item.parts) {
                val partObj = JSONObject()
                partObj.put("text", p.text)
                partsArr.put(partObj)
            }
            contentObj.put("parts", partsArr)
            contentsArray.put(contentObj)
        }

        // Current prompt
        val currentObj = JSONObject()
        currentObj.put("role", "user")
        val curParts = JSONArray()
        val curPart = JSONObject().put("text", currentPrompt)
        curParts.put(curPart)
        currentObj.put("parts", curParts)
        contentsArray.put(currentObj)

        root.put("contents", contentsArray)

        // System instruction
        val sysInstructionObj = JSONObject()
        val sysParts = JSONArray()
        sysParts.put(JSONObject().put("text", SYSTEM_INSTRUCTION))
        sysInstructionObj.put("parts", sysParts)
        root.put("systemInstruction", sysInstructionObj)

        // Generation Config
        val genConfig = JSONObject()
        genConfig.put("temperature", 0.7)
        genConfig.put("maxOutputTokens", 2048)
        root.put("generationConfig", genConfig)

        return root
    }

    private fun extractCandidateText(rootObj: JSONObject): String {
        val candidates = rootObj.optJSONArray("candidates") ?: return ""
        if (candidates.length() == 0) return ""
        val candidate = candidates.getJSONObject(0)
        val content = candidate.optJSONObject("content") ?: return ""
        val parts = content.optJSONArray("parts") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val part = parts.getJSONObject(i)
            sb.append(part.optString("text", ""))
        }
        return sb.toString()
    }

    private fun parseErrorMessage(errorBody: String, statusCode: Int): String {
        return try {
            val obj = JSONObject(errorBody)
            val err = obj.optJSONObject("error")
            val msg = err?.optString("message", "") ?: ""
            if (msg.isNotEmpty()) {
                "Error ($statusCode): $msg"
            } else {
                "HTTP $statusCode: Server returned an error"
            }
        } catch (_: Exception) {
            "HTTP $statusCode error occurred. Please verify your internet connection and API key."
        }
    }
}

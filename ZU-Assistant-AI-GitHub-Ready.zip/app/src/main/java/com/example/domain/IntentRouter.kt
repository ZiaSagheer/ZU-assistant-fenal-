package com.example.domain

import android.provider.Settings
import com.example.device.DeviceController
import java.util.Locale

sealed interface IntentResult {
    data class LocalAction(
        val actionType: String,
        val feedbackEnglish: String,
        val feedbackUrdu: String,
        val feedbackRomanUrdu: String,
        val success: Boolean,
        val metadata: Map<String, Any> = emptyMap()
    ) : IntentResult

    data class AiQuery(
        val prompt: String,
        val detectedLanguage: LanguageType
    ) : IntentResult
}

enum class LanguageType {
    URDU_SCRIPT,
    ROMAN_URDU,
    ENGLISH
}

class IntentRouter(private val deviceController: DeviceController) {

    /**
     * Detects script type: Urdu script (Arabic unicode range), Roman Urdu, or English
     */
    fun detectLanguage(rawText: String): LanguageType {
        // Arabic / Urdu unicode range: \u0600 - \u06FF, \u0750 - \u077F, \uFB50 - \uFDFF, \uFE70 - \uFEFF
        val urduCharCount = rawText.count { char ->
            char in '\u0600'..'\u06FF' || char in '\u0750'..'\u077F' || char in '\uFB50'..'\uFDFF'
        }

        if (urduCharCount > 0 && urduCharCount >= rawText.length / 4) {
            return LanguageType.URDU_SCRIPT
        }

        val lower = rawText.lowercase(Locale.ROOT)
        val romanUrduKeywords = listOf(
            "kya", "haal", "kaise", "karo", "khol", "kholo", "batao", "hai", "hain", "meri", "mera",
            "mujhe", "ap", "aap", "shukriya", "bhai", "tareekh", "din", "waqt", "torch", "batti",
            "band", "chalao", "likho", "bhejo", "wala", "wali", "thik", "theek", "acha", "achi"
        )

        val words = lower.split(Regex("\\s+"))
        val matchCount = words.count { it in romanUrduKeywords }

        return if (matchCount >= 1 || lower.contains("assalam") || lower.contains("kya haal")) {
            LanguageType.ROMAN_URDU
        } else {
            LanguageType.ENGLISH
        }
    }

    /**
     * Normalizes input: removes punctuation, trims spaces, handles variations
     */
    fun normalize(input: String): String {
        return input.trim()
            .replace(Regex("[.,!?:;۔؟]"), "")
            .replace(Regex("\\s+"), " ")
    }

    /**
     * Dispatches intent to either local deterministic handler or AI query
     */
    fun route(rawText: String): IntentResult {
        val lang = detectLanguage(rawText)
        val norm = normalize(rawText)
        val lower = norm.lowercase(Locale.ROOT)

        // 1. Flashlight / Torch ON
        if (containsAny(lower, "torch on", "flashlight on", "torch chalao", "light on", "batti jalao", "light jalao", "torch chala do") ||
            containsAny(norm, "ٹارچ آن کرو", "ٹارچ جلاؤ", "لائٹ جلاؤ", "ٹارچ آن کر دیں", "ٹارچ آن")
        ) {
            val (success, _) = deviceController.toggleTorch(true)
            return IntentResult.LocalAction(
                actionType = "TORCH_ON",
                feedbackEnglish = if (success) "Flashlight turned ON." else "Could not turn on flashlight.",
                feedbackUrdu = if (success) "ٹارچ آن کر دی گئی ہے۔" else "ٹارچ آن کرنے میں مسئلہ پیش آیا۔",
                feedbackRomanUrdu = if (success) "Torch on kar di gayi hai." else "Torch on nahi ho saki.",
                success = success
            )
        }

        // 2. Flashlight / Torch OFF
        if (containsAny(lower, "torch off", "flashlight off", "torch band", "light off", "batti bujhao", "light band", "torch roko") ||
            containsAny(norm, "ٹارچ بند کرو", "ٹارچ بند کر دیں", "لائٹ بند کرو", "ٹارچ آف")
        ) {
            val (success, _) = deviceController.toggleTorch(false)
            return IntentResult.LocalAction(
                actionType = "TORCH_OFF",
                feedbackEnglish = if (success) "Flashlight turned OFF." else "Could not turn off flashlight.",
                feedbackUrdu = if (success) "ٹارچ بند کر دی گئی ہے۔" else "ٹارچ بند کرنے میں مسئلہ پیش آیا۔",
                feedbackRomanUrdu = if (success) "Torch band kar di gayi hai." else "Torch band nahi ho saki.",
                success = success
            )
        }

        // 3. Battery status
        if (containsAny(lower, "battery", "charging", "battery kitni", "battery level", "charge kitna") ||
            containsAny(norm, "بیٹری", "چارجنگ", "بیٹری کتنی ہے", "بیٹری چیک کرو")
        ) {
            val info = deviceController.getBatteryStatus()
            val roman = "Battery ${info.percentage}% hai aur ${if (info.isCharging) "charging ho rahi hai ⚡" else "charging nahi ho rahi"}."
            return IntentResult.LocalAction(
                actionType = "BATTERY_CHECK",
                feedbackEnglish = info.descriptionEnglish,
                feedbackUrdu = info.descriptionUrdu,
                feedbackRomanUrdu = roman,
                success = true,
                metadata = mapOf("percentage" to info.percentage, "charging" to info.isCharging)
            )
        }

        // 4. Date & Time
        if (containsAny(lower, "time", "date", "din aur tareekh", "kya waqt", "waqt kya", "tareekh batao", "aaj ka din", "today date") ||
            containsAny(norm, "وقت", "تاریخ", "آج کا دن", "وقت کیا ہوا", "تاریخ بتاؤ")
        ) {
            val dt = deviceController.getCurrentDateTime()
            val roman = "Is waqt ${dt.time} baj rahe hain aur aaj ${dt.date} hai."
            return IntentResult.LocalAction(
                actionType = "DATE_TIME",
                feedbackEnglish = dt.formattedEnglish,
                feedbackUrdu = dt.formattedUrdu,
                feedbackRomanUrdu = roman,
                success = true,
                metadata = mapOf("time" to dt.time, "date" to dt.date)
            )
        }

        // 5. Open WhatsApp
        if (containsAny(lower, "whatsapp kholo", "open whatsapp", "whatsapp open", "launch whatsapp") ||
            containsAny(norm, "واٹس ایپ کھولو", "واٹس ایپ اوپن کرو")
        ) {
            val (success, msg) = deviceController.openApp("com.whatsapp")
            return IntentResult.LocalAction(
                actionType = "OPEN_APP",
                feedbackEnglish = if (success) "Opening WhatsApp." else msg,
                feedbackUrdu = if (success) "واٹس ایپ کھولی جا رہی ہے۔" else "واٹس ایپ دستیاب نہیں ہے۔",
                feedbackRomanUrdu = if (success) "WhatsApp khola ja raha hai." else "WhatsApp nahi mil saki.",
                success = success
            )
        }

        // 6. Open YouTube
        if (containsAny(lower, "youtube kholo", "open youtube", "youtube open", "launch youtube") ||
            containsAny(norm, "یوٹیوب کھولو", "یوٹیوب اوپن کرو")
        ) {
            val (success, msg) = deviceController.openApp("com.google.android.youtube")
            return IntentResult.LocalAction(
                actionType = "OPEN_APP",
                feedbackEnglish = if (success) "Opening YouTube." else msg,
                feedbackUrdu = if (success) "یوٹیوب کھولی جا رہی ہے۔" else "یوٹیوب دستیاب نہیں ہے۔",
                feedbackRomanUrdu = if (success) "YouTube khola ja raha hai." else "YouTube nahi mil saki.",
                success = success
            )
        }

        // 7. Open Camera
        if (containsAny(lower, "camera kholo", "open camera", "tasveer khicho") ||
            containsAny(norm, "کیمرہ کھولو", "کیمرہ اوپن کرو")
        ) {
            val (success, msg) = deviceController.openApp("com.android.camera")
            return IntentResult.LocalAction(
                actionType = "OPEN_APP",
                feedbackEnglish = if (success) "Opening Camera." else msg,
                feedbackUrdu = if (success) "کیمرہ کھولا جا رہا ہے۔" else "کیمرہ ایپلیکیشن نہیں ملی۔",
                feedbackRomanUrdu = if (success) "Camera khola ja raha hai." else "Camera app nahi mili.",
                success = success
            )
        }

        // 8. Open Wi-Fi Settings
        if (containsAny(lower, "wifi settings", "wi-fi settings", "wifi kholo", "wifi khol do") ||
            containsAny(norm, "وائی فائی سیٹنگز", "وائی فائی کھولو")
        ) {
            val (success, msg) = deviceController.openSettings(Settings.ACTION_WIFI_SETTINGS)
            return IntentResult.LocalAction(
                actionType = "SETTINGS_WIFI",
                feedbackEnglish = "Opening Wi-Fi Settings.",
                feedbackUrdu = "وائی فائی سیٹنگز کھولی جا رہی ہیں۔",
                feedbackRomanUrdu = "Wi-Fi settings kholi ja rahi hain.",
                success = success
            )
        }

        // 9. Open Bluetooth Settings
        if (containsAny(lower, "bluetooth settings", "bluetooth kholo", "bluetooth on karo") ||
            containsAny(norm, "بلوٹوتھ سیٹنگز", "بلوٹوتھ کھولو")
        ) {
            val (success, msg) = deviceController.openSettings(Settings.ACTION_BLUETOOTH_SETTINGS)
            return IntentResult.LocalAction(
                actionType = "SETTINGS_BLUETOOTH",
                feedbackEnglish = "Opening Bluetooth Settings.",
                feedbackUrdu = "بلوٹوتھ ترتیبات کھولی جا رہی ہیں۔",
                feedbackRomanUrdu = "Bluetooth settings kholi ja rahi hain.",
                success = success
            )
        }

        // 10. Open Display Settings
        if (containsAny(lower, "display settings", "brightness settings", "screen settings") ||
            containsAny(norm, "ڈسپلے سیٹنگز", "اسکرین سیٹنگز")
        ) {
            val (success, msg) = deviceController.openSettings(Settings.ACTION_DISPLAY_SETTINGS)
            return IntentResult.LocalAction(
                actionType = "SETTINGS_DISPLAY",
                feedbackEnglish = "Opening Display Settings.",
                feedbackUrdu = "ڈسپلے ترتیبات کھولی جا رہی ہیں۔",
                feedbackRomanUrdu = "Display settings kholi ja rahi hain.",
                success = success
            )
        }

        // Share App (واٹس ایپ یا دیگر ایپس پر شیئر کریں)
        if (containsAny(lower, "share app", "app share", "share karo", "kisi ko bhejo", "app bhejo") ||
            containsAny(norm, "ایپ شیئر کرو", "ایپ شیئر کریں", "شیئر کرو", "ایپ بھیجو")
        ) {
            val isWhatsApp = containsAny(lower, "whatsapp", "wa") || containsAny(norm, "واٹس ایپ")
            val targetPkg = if (isWhatsApp) "com.whatsapp" else null
            val (success, _) = deviceController.shareApp(targetPkg)
            return IntentResult.LocalAction(
                actionType = "SHARE_APP",
                feedbackEnglish = "Opening share options for ZU Assistant.",
                feedbackUrdu = "زیڈ یو اسسٹنٹ کو شیئر کرنے کے لیے مینیو کھولا جا رہا ہے۔",
                feedbackRomanUrdu = "ZU Assistant ko share karne ke liye options khole ja rahe hain.",
                success = success
            )
        }

        // 11. Quick Math / Arithmetic Calculations
        val mathResult = tryEvaluateMath(lower)
        if (mathResult != null) {
            return IntentResult.LocalAction(
                actionType = "CALCULATOR",
                feedbackEnglish = "Calculation: $lower = $mathResult",
                feedbackUrdu = "جواب: $mathResult ہے",
                feedbackRomanUrdu = "Result: $mathResult hai",
                success = true,
                metadata = mapOf("result" to mathResult)
            )
        }

        // 12. Islamic Greetings in Urdu/Roman
        if (lower.startsWith("assalam") || lower.contains("salam") || norm.contains("السلام علیکم")) {
            return IntentResult.LocalAction(
                actionType = "GREETING",
                feedbackEnglish = "Walaikum Assalam! I am ZU Assistant, how can I assist you today?",
                feedbackUrdu = "وعلیکم السلام! میں آپ کا زیڈ یو اسسٹنٹ ہوں۔ آج میں آپ کی کیا مدد کر سکتا ہوں؟",
                feedbackRomanUrdu = "Walaikum Assalam! Main ZU Assistant hoon. Aaj main aap ki kya madad kar sakta hoon?",
                success = true
            )
        }

        // 13. "Who are you?" / "Tum kaun ho"
        if (containsAny(lower, "who are you", "tum kaun ho", "aap kon hain", "intro", "apna taaruf") ||
            containsAny(norm, "آپ کون ہیں", "تم کون ہو", "اپنا تعارف کروائیں")
        ) {
            return IntentResult.LocalAction(
                actionType = "INTRO",
                feedbackEnglish = "I am ZU Assistant, your intelligent Android personal assistant supporting Urdu, Roman Urdu, and English.",
                feedbackUrdu = "میں زیڈ یو اسسٹنٹ ہوں، آپ کا ذاتی اینڈرائیڈ اسسٹنٹ۔ میں اردو، رومن اردو اور انگریزی سمجھتا ہوں اور آپ کے فون کنٹرولز اور سوالات میں مدد کرتا ہوں۔",
                feedbackRomanUrdu = "Main ZU Assistant hoon, aap ka personal Android AI assistant. Main Urdu, Roman Urdu aur English samajhta hoon.",
                success = true
            )
        }

        // Fallback: Complex / Conversational AI Query
        return IntentResult.AiQuery(
            prompt = rawText,
            detectedLanguage = lang
        )
    }

    private fun containsAny(text: String, vararg keywords: String): Boolean {
        return keywords.any { text.contains(it, ignoreCase = true) }
    }

    private fun tryEvaluateMath(text: String): Double? {
        val sanitized = text.replace("plus", "+")
            .replace("minus", "-")
            .replace("multiply", "*")
            .replace("times", "*")
            .replace("x", "*")
            .replace("divide", "/")
            .replace("divided by", "/")
            .replace("into", "*")
            .trim()

        val pattern = Regex("^(\\d+(?:\\.\\d+)?)\\s*([+\\-*/])\\s*(\\d+(?:\\.\\d+)?)$")
        val match = pattern.find(sanitized) ?: return null
        val num1 = match.groupValues[1].toDoubleOrNull() ?: return null
        val op = match.groupValues[2]
        val num2 = match.groupValues[3].toDoubleOrNull() ?: return null

        return when (op) {
            "+" -> num1 + num2
            "-" -> num1 - num2
            "*" -> num1 * num2
            "/" -> if (num2 != 0.0) num1 / num2 else null
            else -> null
        }
    }
}

package com.example.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.ScreenDestination
import com.example.ui.components.AiOrb
import com.example.ui.components.MarkdownText
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.PrimaryNeonGradient
import com.example.ui.theme.VioletNeon
import com.example.ui.theme.VioletPrimary
import com.example.voice.VoiceAssistantManager
import com.example.voice.VoiceState

@Composable
fun VoiceAssistantScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val voiceState by viewModel.voiceState.collectAsState()
    val rmsDb by viewModel.rmsDb.collectAsState()
    val selectedLang by viewModel.voiceAssistantManager.selectedLanguage.collectAsState()
    val liveTranscript by viewModel.voiceAssistantManager.liveTranscript.collectAsState()
    val messages by viewModel.currentMessages.collectAsState()

    val lastUserMessage = messages.lastOrNull { it.sender == "user" }?.content
    val lastModelMessage = messages.lastOrNull { it.sender == "model" }?.content

    var textFallbackInput by remember { mutableStateOf("") }
    var showFallbackInput by remember { mutableStateOf(false) }

    // Audio Permission Launcher
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.voiceAssistantManager.startListening()
        }
    }

    val sampleVoiceCommands = listOf(
        "Torch on karo" to "ٹارچ آن کرو",
        "Torch band karo" to "ٹارچ بند کرو",
        "Battery kitni hai?" to "بیٹری کی حالت بتاؤ",
        "WhatsApp kholo" to "واٹس ایپ کھولیں",
        "Aaj kya tareekh hai?" to "آج کا دن اور تاریخ",
        "Assalamu Alaikum" to "السلام علیکم",
        "Mujhe Urdu mein jawab do" to "اردو میں بات کرو",
        "Open YouTube" to "یوٹیوب کھولیں"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "SPEECH ASSISTANT",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = CyanAccent
                )
                Text(
                    text = "آوازی معاون (اردو / Roman / English)",
                    style = MaterialTheme.typography.labelSmall,
                    color = VioletNeon
                )
            }

            IconButton(
                onClick = {
                    viewModel.voiceAssistantManager.stopListening()
                    viewModel.voiceAssistantManager.stopSpeaking()
                    viewModel.navigateTo(ScreenDestination.DASHBOARD)
                }
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Close Voice Screen",
                    tint = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Language Mode Selector Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            LanguageFilterPill(
                label = "🌐 Auto (خودکار)",
                isSelected = selectedLang == VoiceAssistantManager.LANG_AUTO,
                onClick = { viewModel.voiceAssistantManager.setSpeechLanguage(VoiceAssistantManager.LANG_AUTO) }
            )
            Spacer(modifier = Modifier.width(8.dp))
            LanguageFilterPill(
                label = "🇵🇰 اردو (Urdu)",
                isSelected = selectedLang == VoiceAssistantManager.LANG_URDU,
                onClick = { viewModel.voiceAssistantManager.setSpeechLanguage(VoiceAssistantManager.LANG_URDU) }
            )
            Spacer(modifier = Modifier.width(8.dp))
            LanguageFilterPill(
                label = "🇬🇧 English",
                isSelected = selectedLang == VoiceAssistantManager.LANG_ENGLISH,
                onClick = { viewModel.voiceAssistantManager.setSpeechLanguage(VoiceAssistantManager.LANG_ENGLISH) }
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Center Voice Orb Stage & Transcripts
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Interactive AI Orb with dynamic audio reactivity
                AiOrb(
                    voiceState = voiceState,
                    rmsDb = rmsDb,
                    onClick = {
                        if (!viewModel.voiceAssistantManager.isPermissionGranted()) {
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        } else {
                            when (voiceState) {
                                is VoiceState.Listening -> viewModel.voiceAssistantManager.stopListening()
                                is VoiceState.Speaking -> viewModel.voiceAssistantManager.stopSpeaking()
                                else -> viewModel.voiceAssistantManager.startListening()
                            }
                        }
                    },
                    size = 210.dp
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Real-time Status & Live Transcription
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
                    ) {
                        Text(
                            text = when (val state = voiceState) {
                                is VoiceState.Listening -> "🎙️ Listening... (بولیں، سن رہا ہوں)"
                                is VoiceState.Processing -> "⚡ Processing... (تجزیہ ہو رہا ہے)"
                                is VoiceState.Speaking -> "🔊 Speaking... Tap Orb to interrupt"
                                is VoiceState.Error -> "⚠️ ${state.message}"
                                else -> "Tap Orb to speak / مائیک دبائیں"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = when (voiceState) {
                                is VoiceState.Listening -> CyanGlow
                                is VoiceState.Speaking -> VioletNeon
                                is VoiceState.Error -> Color(0xFFEF4444)
                                else -> MaterialTheme.colorScheme.onSurface
                            },
                            textAlign = TextAlign.Center
                        )

                        // Live partial transcript streaming as the user talks
                        val currentPartial = (voiceState as? VoiceState.Listening)?.partialTranscript
                            ?: (voiceState as? VoiceState.Processing)?.query
                            ?: liveTranscript

                        if (currentPartial.isNotBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "“$currentPartial”",
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp
                                ),
                                color = CyanAccent,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                // If microphone permission is missing, show direct permission button
                if (!viewModel.voiceAssistantManager.isPermissionGranted()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                        colors = ButtonDefaults.buttonColors(containerColor = VioletPrimary),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Grant Microphone Permission", fontSize = 13.sp)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Last Interaction Preview Card
                if (!lastUserMessage.isNullOrEmpty() || !lastModelMessage.isNullOrEmpty()) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            if (!lastUserMessage.isNullOrEmpty()) {
                                Text(
                                    text = "You said (آپ نے کہا):",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CyanAccent,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = lastUserMessage,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                            }

                            if (!lastModelMessage.isNullOrEmpty()) {
                                Text(
                                    text = "ZU Assistant:",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = VioletNeon,
                                    fontWeight = FontWeight.Bold
                                )
                                MarkdownText(text = lastModelMessage)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Quick Voice Command Suggestions
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = "Try saying (یہ بول کر آزمائیں):",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 12.dp, bottom = 6.dp)
                    )
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(sampleVoiceCommands) { (cmdRoman, cmdUrdu) ->
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f),
                                border = CardDefaults.outlinedCardBorder(),
                                modifier = Modifier.clickable {
                                    viewModel.handleUserInput(cmdRoman, fromVoice = true)
                                }
                            ) {
                                Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                                    Text(
                                        text = cmdRoman,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = CyanAccent,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = cmdUrdu,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Voice Controls Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Text Fallback toggle button
            Button(
                onClick = { showFallbackInput = !showFallbackInput },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(20.dp)
            ) {
                Text(
                    text = if (showFallbackInput) "Hide Keyboard" else "Text Fallback",
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Action button depending on current state
            when (val state = voiceState) {
                is VoiceState.Speaking -> {
                    Button(
                        onClick = { viewModel.voiceAssistantManager.stopSpeaking() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Icon(Icons.Default.VolumeOff, contentDescription = "Stop Speech", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Stop Speech", color = Color.White, fontSize = 12.sp)
                    }
                }
                is VoiceState.Listening -> {
                    Button(
                        onClick = { viewModel.voiceAssistantManager.stopListening() },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanAccent),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Icon(Icons.Default.Stop, contentDescription = "Stop Listening", tint = Color.Black, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Stop", color = Color.Black, fontSize = 12.sp)
                    }
                }
                is VoiceState.Error -> {
                    Button(
                        onClick = { viewModel.voiceAssistantManager.startListening() },
                        colors = ButtonDefaults.buttonColors(containerColor = VioletPrimary),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Retry", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Try Again", color = Color.White, fontSize = 12.sp)
                    }
                }
                else -> {
                    Button(
                        onClick = {
                            if (!viewModel.voiceAssistantManager.isPermissionGranted()) {
                                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            } else {
                                viewModel.voiceAssistantManager.startListening()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = VioletPrimary),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = "Start Mic", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Start Mic", color = Color.White, fontSize = 12.sp)
                    }
                }
            }
        }

        // Text Fallback Input Container
        AnimatedVisibility(visible = showFallbackInput) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = textFallbackInput,
                        onValueChange = { textFallbackInput = it },
                        placeholder = { Text("Type voice command or query...", fontSize = 13.sp) },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanAccent,
                            unfocusedBorderColor = Color.Transparent
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            if (textFallbackInput.isNotBlank()) {
                                viewModel.handleUserInput(textFallbackInput, fromVoice = true)
                                textFallbackInput = ""
                            }
                        },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(PrimaryNeonGradient)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send text fallback",
                            tint = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LanguageFilterPill(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (isSelected) VioletPrimary else MaterialTheme.colorScheme.surfaceVariant,
        border = if (isSelected) null else CardDefaults.outlinedCardBorder(),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}

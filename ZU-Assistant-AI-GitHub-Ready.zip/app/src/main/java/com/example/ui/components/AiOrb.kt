package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.VioletNeon
import com.example.ui.theme.VioletPrimary
import com.example.voice.VoiceState
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun AiOrb(
    voiceState: VoiceState,
    rmsDb: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 180.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_pulse")

    // Slow continuous rotation
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    // Breathing pulse for idle/listening
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (voiceState) {
                    is VoiceState.Listening -> 1000
                    is VoiceState.Processing -> 600
                    is VoiceState.Speaking -> 1200
                    else -> 2400
                },
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    // Outer glow ring wave
    val waveAlpha by infiniteTransition.animateFloat(
        initialValue = 0.7f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_alpha"
    )

    val waveScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.4f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_scale"
    )

    // React to speech volume
    val voiceAudioScale = 1.0f + (rmsDb.coerceIn(0f, 10f) / 25f)
    val effectiveScale = pulseScale * voiceAudioScale

    val orbColors = when (voiceState) {
        is VoiceState.Listening -> listOf(CyanGlow, CyanAccent, VioletNeon)
        is VoiceState.Processing -> listOf(Color(0xFFF59E0B), VioletNeon, CyanAccent)
        is VoiceState.Speaking -> listOf(VioletNeon, Color(0xFFEC4899), CyanGlow)
        is VoiceState.Error -> listOf(Color(0xFFEF4444), Color(0xFFDC2626), VioletPrimary)
        else -> listOf(CyanGlow, VioletNeon, VioletPrimary)
    }

    Box(
        modifier = modifier
            .size(size)
            .testTag("ai_orb_button")
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        // Outer pulsing ring 1 (for listening/speaking)
        if (voiceState is VoiceState.Listening || voiceState is VoiceState.Speaking) {
            Canvas(
                modifier = Modifier
                    .size(size)
                    .scale(waveScale)
            ) {
                drawCircle(
                    color = orbColors.first().copy(alpha = waveAlpha * 0.5f),
                    radius = this.size.minDimension / 2f,
                    style = Stroke(width = 3.dp.toPx())
                )
            }
        }

        // Inner glowing core Canvas
        Canvas(
            modifier = Modifier
                .size(size * 0.82f)
                .scale(effectiveScale)
                .rotate(rotation)
        ) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val radius = this.size.minDimension / 2f

            // Radial background glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        orbColors[0].copy(alpha = 0.85f),
                        orbColors[1].copy(alpha = 0.55f),
                        orbColors[2].copy(alpha = 0.25f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = radius
                ),
                radius = radius,
                center = center
            )

            // Orbiting planetary accent dots
            for (i in 0 until 4) {
                val angle = Math.toRadians((i * 90.0) + (rotation * 1.5))
                val orbitRadius = radius * 0.68f
                val dotX = center.x + (orbitRadius * cos(angle)).toFloat()
                val dotY = center.y + (orbitRadius * sin(angle)).toFloat()
                drawCircle(
                    color = orbColors[i % orbColors.size].copy(alpha = 0.9f),
                    radius = 3.5.dp.toPx(),
                    center = Offset(dotX, dotY)
                )
            }
        }

        // Center glass button with icon
        Box(
            modifier = Modifier
                .size(size * 0.46f)
                .clip(CircleShape)
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(0xFF1E293B).copy(alpha = 0.9f),
                            Color(0xFF0F172A).copy(alpha = 0.95f)
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            val icon = when (voiceState) {
                is VoiceState.Listening -> Icons.Filled.Stop
                is VoiceState.Speaking -> Icons.Filled.VolumeUp
                else -> Icons.Filled.Mic
            }
            val tint = when (voiceState) {
                is VoiceState.Listening -> CyanGlow
                is VoiceState.Speaking -> VioletNeon
                is VoiceState.Error -> Color(0xFFEF4444)
                else -> Color.White
            }
            Icon(
                imageVector = icon,
                contentDescription = "AI Voice Orb",
                tint = tint,
                modifier = Modifier.size(size * 0.22f)
            )
        }
    }
}

package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DisplaySettings
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.PrimaryNeonGradient
import com.example.ui.theme.VioletNeon
import com.example.ui.theme.VioletPrimary

@Composable
fun DeviceToolsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isTorchOn by viewModel.isTorchOn.collectAsState()
    val batteryInfo by viewModel.batteryInfo.collectAsState()
    val dateTimeInfo by viewModel.dateTimeInfo.collectAsState()

    // WhatsApp Smart Composer State
    var recipientNumber by remember { mutableStateOf("") }
    var draftMessage by remember { mutableStateOf("") }
    var showWhatsAppConfirmDialog by remember { mutableStateOf(false) }

    // Alarm/Timer Dialog State
    var showAlarmDialog by remember { mutableStateOf(false) }
    var alarmHourText by remember { mutableStateOf("07") }
    var alarmMinuteText by remember { mutableStateOf("00") }
    var alarmLabelText by remember { mutableStateOf("Wake Up") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "DEVICE CONTROLS & TOOLS",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = CyanAccent
                )
                Text(
                    text = "سمارٹ ڈیوائس کنٹرولز",
                    style = MaterialTheme.typography.labelSmall,
                    color = VioletNeon
                )
            }
        }

        // 1. WhatsApp Smart Messaging Assistant Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        Brush.horizontalGradient(listOf(EmeraldSuccess.copy(alpha = 0.5f), CyanAccent.copy(alpha = 0.5f))),
                        RoundedCornerShape(16.dp)
                    )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(EmeraldSuccess.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = null,
                                tint = EmeraldSuccess,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "WhatsApp Message Assistant",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Draft in Urdu or English & review before sending",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = recipientNumber,
                        onValueChange = { recipientNumber = it },
                        label = { Text("Recipient Phone (e.g. +923001234567)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("whatsapp_number_input"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = draftMessage,
                        onValueChange = { draftMessage = it },
                        label = { Text("Draft Message (Urdu / Roman / English)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("whatsapp_message_input"),
                        maxLines = 4
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Preset buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier
                                .clickable { draftMessage = "السلام علیکم! کیا حال ہے؟" }
                                .padding(2.dp)
                        ) {
                            Text("السلام علیکم", fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier
                                .clickable { draftMessage = "I am on my way, will reach soon." }
                                .padding(2.dp)
                        ) {
                            Text("On my way", fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier
                                .clickable { draftMessage = "Meeting confirm hai aaj?" }
                                .padding(2.dp)
                        ) {
                            Text("Meeting?", fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Copy Button
                        IconButton(
                            onClick = {
                                if (draftMessage.isNotEmpty()) {
                                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    cm.setPrimaryClip(ClipData.newPlainText("draft", draftMessage))
                                    Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
                                }
                            }
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy")
                        }

                        // Share Intent Button
                        IconButton(
                            onClick = {
                                if (draftMessage.isNotEmpty()) {
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, draftMessage)
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "Share Message"))
                                }
                            }
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "Share")
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // Review & Launch WhatsApp (Mandatory explicit confirmation!)
                        Button(
                            onClick = {
                                if (draftMessage.isBlank()) {
                                    Toast.makeText(context, "Please enter a message to review", Toast.LENGTH_SHORT).show()
                                } else {
                                    showWhatsAppConfirmDialog = true
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                            modifier = Modifier.testTag("whatsapp_review_button")
                        ) {
                            Text("Review & Open WhatsApp", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 2. Hardware Controls Grid (Torch, Alarm, Network, Battery)
        item {
            Text(
                text = "Hardware & System Shortcuts",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ToolActionCard(
                    title = "Flashlight",
                    state = if (isTorchOn) "Active (ON)" else "Off",
                    icon = if (isTorchOn) Icons.Default.FlashlightOn else Icons.Default.FlashlightOff,
                    color = if (isTorchOn) Color(0xFFF59E0B) else Color(0xFF94A3B8),
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.toggleTorch() }
                )

                ToolActionCard(
                    title = "Set Alarm",
                    state = "Android Clock",
                    icon = Icons.Default.Alarm,
                    color = VioletNeon,
                    modifier = Modifier.weight(1f),
                    onClick = { showAlarmDialog = true }
                )
            }
        }

        // 3. Quick System Settings Shortcuts
        item {
            Text(
                text = "Android System Settings",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ToolActionCard(
                    title = "Wi-Fi",
                    state = "Settings",
                    icon = Icons.Default.Wifi,
                    color = CyanAccent,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.deviceController.openSettings(Settings.ACTION_WIFI_SETTINGS) }
                )

                ToolActionCard(
                    title = "Bluetooth",
                    state = "Settings",
                    icon = Icons.Default.Bluetooth,
                    color = Color(0xFF38BDF8),
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.deviceController.openSettings(Settings.ACTION_BLUETOOTH_SETTINGS) }
                )

                ToolActionCard(
                    title = "Display",
                    state = "Brightness",
                    icon = Icons.Default.DisplaySettings,
                    color = Color(0xFFA855F7),
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.deviceController.openSettings(Settings.ACTION_DISPLAY_SETTINGS) }
                )

                ToolActionCard(
                    title = "Sound",
                    state = "Volume",
                    icon = Icons.Default.VolumeUp,
                    color = Color(0xFFEC4899),
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.deviceController.openSettings(Settings.ACTION_SOUND_SETTINGS) }
                )
            }
        }

        // 4. App Launchers (Camera, YouTube, Phone Dialer, Browser)
        item {
            Text(
                text = "Installed Apps",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ToolActionCard(
                    title = "YouTube",
                    state = "Open App",
                    icon = Icons.Default.PlayCircle,
                    color = Color(0xFFEF4444),
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.deviceController.openApp("com.google.android.youtube") }
                )

                ToolActionCard(
                    title = "Camera",
                    state = "Capture",
                    icon = Icons.Default.CameraAlt,
                    color = CyanAccent,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        val (success, msg) = viewModel.deviceController.openApp("com.android.camera")
                        if (!success) Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    }
                )

                ToolActionCard(
                    title = "Phone",
                    state = "Dialer",
                    icon = Icons.Default.Phone,
                    color = EmeraldSuccess,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        val intent = Intent(Intent.ACTION_DIAL)
                        context.startActivity(intent)
                    }
                )

                ToolActionCard(
                    title = "Browser",
                    state = "Web",
                    icon = Icons.Default.Language,
                    color = Color(0xFF38BDF8),
                    modifier = Modifier.weight(1f),
                    onClick = {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))
                        context.startActivity(intent)
                    }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    // Explicit Confirmation Dialog for WhatsApp sending
    if (showWhatsAppConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showWhatsAppConfirmDialog = false },
            title = { Text("Confirm WhatsApp Message") },
            text = {
                Column {
                    Text(
                        text = "Safety Check: ZU Assistant will never send messages automatically. Review the draft below before opening WhatsApp:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    if (recipientNumber.isNotBlank()) {
                        Text(
                            text = "To: $recipientNumber",
                            fontWeight = FontWeight.Bold,
                            color = CyanAccent,
                            fontSize = 13.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = draftMessage,
                            modifier = Modifier.padding(10.dp),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deviceController.prepareWhatsAppDraft(recipientNumber, draftMessage)
                        showWhatsAppConfirmDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
                ) {
                    Text("Proceed to WhatsApp")
                }
            },
            dismissButton = {
                TextButton(onClick = { showWhatsAppConfirmDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Set Alarm Dialog
    if (showAlarmDialog) {
        AlertDialog(
            onDismissRequest = { showAlarmDialog = false },
            title = { Text("Set Device Alarm") },
            text = {
                Column {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = alarmHourText,
                            onValueChange = { alarmHourText = it },
                            label = { Text("Hour (0-23)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = alarmMinuteText,
                            onValueChange = { alarmMinuteText = it },
                            label = { Text("Minute (0-59)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = alarmLabelText,
                        onValueChange = { alarmLabelText = it },
                        label = { Text("Alarm Label") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val h = alarmHourText.toIntOrNull() ?: 7
                        val m = alarmMinuteText.toIntOrNull() ?: 0
                        val (success, msg) = viewModel.deviceController.setAlarm(h, m, alarmLabelText)
                        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                        showAlarmDialog = false
                    }
                ) {
                    Text("Set Alarm")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAlarmDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun ToolActionCard(
    title: String,
    state: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
            Text(
                text = state,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
    }
}

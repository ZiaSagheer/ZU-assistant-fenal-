package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.ScreenDestination
import com.example.ui.components.AiOrb
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.DarkCardGradient
import com.example.ui.theme.PrimaryNeonGradient
import com.example.ui.theme.VioletNeon
import com.example.ui.theme.VioletPrimary
import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.example.voice.VoiceState

@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val voiceState by viewModel.voiceState.collectAsState()
    val rmsDb by viewModel.rmsDb.collectAsState()
    val liveTranscript by viewModel.voiceAssistantManager.liveTranscript.collectAsState()
    val batteryInfo by viewModel.batteryInfo.collectAsState()
    val dateTimeInfo by viewModel.dateTimeInfo.collectAsState()
    val isTorchOn by viewModel.isTorchOn.collectAsState()
    val recentSessions by viewModel.allSessions.collectAsState()
    val feedbackMsg by viewModel.lastActionFeedback.collectAsState()

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.voiceAssistantManager.startListening()
        }
    }

    var quickInputText by remember { mutableStateOf("") }

    val promptSuggestions = listOf(
        "Torch on karo" to "ٹارچ آن کرو",
        "Battery kitni hai?" to "بیٹری کتنی ہے؟",
        "WhatsApp kholo" to "واٹس ایپ کھولو",
        "Aaj kya din hai?" to "آج کا دن اور تاریخ",
        "Assalamu Alaikum" to "السلام علیکم",
        "Write a polite message" to "ایک پیغام لکھو"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Header with greeting and status
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "ZU ASSISTANT",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 2.sp,
                            color = CyanAccent
                        )
                    )
                    Text(
                        text = "زیڈ یو اسسٹنٹ",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = VioletNeon
                        )
                    )
                }

                // Status Pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    VioletPrimary.copy(alpha = 0.25f),
                                    CyanAccent.copy(alpha = 0.25f)
                                )
                            )
                        )
                        .border(1.dp, VioletNeon.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (voiceState is VoiceState.Listening) CyanGlow else Color(0xFF10B981))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = when (voiceState) {
                                is VoiceState.Listening -> "Listening..."
                                is VoiceState.Processing -> "Processing..."
                                is VoiceState.Speaking -> "Speaking..."
                                else -> "AI Ready"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        // 2. Telemetry Quick Cards (Battery, Date/Time, Torch Toggle)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                TelemetryCard(
                    title = "Battery",
                    value = "${batteryInfo.percentage}%",
                    subtitle = if (batteryInfo.isCharging) "Charging" else "Discharging",
                    icon = if (batteryInfo.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryFull,
                    iconColor = if (batteryInfo.isCharging) CyanAccent else Color(0xFF10B981),
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.handleUserInput("Battery kitni hai?") }
                )

                TelemetryCard(
                    title = "Flashlight",
                    value = if (isTorchOn) "ON" else "OFF",
                    subtitle = "Tap to toggle",
                    icon = if (isTorchOn) Icons.Default.FlashlightOn else Icons.Default.FlashlightOff,
                    iconColor = if (isTorchOn) Color(0xFFF59E0B) else Color(0xFF94A3B8),
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.toggleTorch() }
                )

                TelemetryCard(
                    title = "Time",
                    value = dateTimeInfo.time,
                    subtitle = dateTimeInfo.date.take(10),
                    icon = Icons.Default.AccessTime,
                    iconColor = VioletNeon,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.handleUserInput("Aaj kya date hai?") }
                )
            }
        }

        // Action feedback banner if recently toggled
        if (!feedbackMsg.isNullOrEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = VioletPrimary.copy(alpha = 0.15f),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(VioletPrimary, CyanAccent))),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = feedbackMsg ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        color = CyanGlow,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }
        }

        // 3. Signature Animated Glowing AI Orb
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                AiOrb(
                    voiceState = voiceState,
                    rmsDb = rmsDb,
                    onClick = {
                        if (!viewModel.voiceAssistantManager.isPermissionGranted()) {
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        } else {
                            if (voiceState is VoiceState.Listening) {
                                viewModel.voiceAssistantManager.stopListening()
                            } else if (voiceState is VoiceState.Speaking) {
                                viewModel.voiceAssistantManager.stopSpeaking()
                            } else {
                                viewModel.voiceAssistantManager.startListening()
                            }
                        }
                    },
                    size = 190.dp
                )

                Spacer(modifier = Modifier.height(14.dp))

                val livePartial = (voiceState as? VoiceState.Listening)?.partialTranscript ?: liveTranscript

                Text(
                    text = when {
                        voiceState is VoiceState.Listening && livePartial.isNotBlank() -> "“$livePartial”"
                        voiceState is VoiceState.Listening -> "🎙️ Listening... (بولیں، سن رہا ہوں)"
                        voiceState is VoiceState.Processing -> "⚡ Processing... (سوچ رہا ہوں)"
                        voiceState is VoiceState.Speaking -> "Tap Orb to stop speaking"
                        voiceState is VoiceState.Error -> (voiceState as VoiceState.Error).message
                        else -> "Tap Orb to Speak in Urdu, Roman, or English"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    color = when (voiceState) {
                        is VoiceState.Listening -> CyanGlow
                        is VoiceState.Speaking -> VioletNeon
                        is VoiceState.Error -> Color(0xFFEF4444)
                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                    }
                )
            }
        }

        // 4. Modern Chat Input Bar
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Brush.horizontalGradient(listOf(VioletPrimary.copy(alpha = 0.4f), CyanAccent.copy(alpha = 0.4f))), RoundedCornerShape(24.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = quickInputText,
                        onValueChange = { quickInputText = it },
                        placeholder = {
                            Text(
                                "Ask anything in Urdu, Roman, or English...",
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dashboard_input_field"),
                        maxLines = 3
                    )

                    IconButton(
                        onClick = {
                            if (quickInputText.isNotBlank()) {
                                viewModel.handleUserInput(quickInputText)
                                quickInputText = ""
                                viewModel.navigateTo(ScreenDestination.CHAT)
                            }
                        },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(PrimaryNeonGradient)
                            .size(42.dp)
                            .testTag("dashboard_send_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send prompt",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        // 5. Quick Suggestion Chips (Urdu & Roman Urdu)
        item {
            Column {
                Text(
                    text = "Quick Actions & Commands",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(end = 8.dp)
                ) {
                    items(promptSuggestions) { (roman, urdu) ->
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            border = CardDefaults.outlinedCardBorder(),
                            modifier = Modifier.clickable {
                                viewModel.handleUserInput(roman)
                                viewModel.navigateTo(ScreenDestination.CHAT)
                            }
                        ) {
                            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                                Text(
                                    text = roman,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = CyanAccent
                                )
                                Text(
                                    text = urdu,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // 6. Recent Conversations Preview
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Recent Chats",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "View All",
                    style = MaterialTheme.typography.labelMedium,
                    color = CyanAccent,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { viewModel.navigateTo(ScreenDestination.CHAT) }
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
        }

        if (recentSessions.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Text(
                        text = "No recent chats. Start a conversation with ZU Assistant above!",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        } else {
            items(recentSessions.take(3)) { session ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.selectSession(session.id)
                            viewModel.navigateTo(ScreenDestination.CHAT)
                        }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(VioletPrimary.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Chat,
                                contentDescription = null,
                                tint = VioletNeon,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = session.title,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "Tap to open chat",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun TelemetryCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    iconColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = iconColor,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                ),
                maxLines = 1
            )
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.VioletNeon

@Composable
fun MarkdownText(
    text: String,
    modifier: Modifier = Modifier,
    textColor: Color = MaterialTheme.colorScheme.onSurface
) {
    val context = LocalContext.current
    val blocks = splitMarkdownBlocks(text)

    Column(modifier = modifier) {
        blocks.forEach { block ->
            when (block) {
                is Block.Code -> {
                    CodeSnippetBlock(block.language, block.code, context)
                }
                is Block.Header -> {
                    val isUrdu = isUrduScript(block.text)
                    val dir = if (isUrdu) LayoutDirection.Rtl else LayoutDirection.Ltr
                    CompositionLocalProvider(LocalLayoutDirection provides dir) {
                        Text(
                            text = block.text,
                            style = when (block.level) {
                                1 -> MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = CyanAccent,
                                    fontSize = 20.sp
                                )
                                2 -> MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    color = VioletNeon,
                                    fontSize = 18.sp
                                )
                                else -> MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                            },
                            textAlign = if (isUrdu) TextAlign.Right else TextAlign.Left,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        )
                    }
                }
                is Block.Paragraph -> {
                    val isUrdu = isUrduScript(block.raw)
                    val dir = if (isUrdu) LayoutDirection.Rtl else LayoutDirection.Ltr
                    CompositionLocalProvider(LocalLayoutDirection provides dir) {
                        Text(
                            text = parseInlineFormatting(block.raw, textColor),
                            style = MaterialTheme.typography.bodyMedium.copy(
                                lineHeight = if (isUrdu) 26.sp else 22.sp,
                                fontSize = if (isUrdu) 16.sp else 15.sp
                            ),
                            textAlign = if (isUrdu) TextAlign.Right else TextAlign.Left,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CodeSnippetBlock(language: String, code: String, context: Context) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF0D1117))
            .border(1.dp, Color(0xFF30363D), RoundedCornerShape(8.dp))
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header bar with language tag and copy button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF161B22))
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = language.ifEmpty { "code" },
                    color = Color(0xFF8B949E),
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.weight(1f))
                IconButton(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("code", code))
                        Toast.makeText(context, "Code copied", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy code",
                        tint = Color(0xFF8B949E),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            Text(
                text = code,
                color = Color(0xFFE6EDF3),
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                lineHeight = 18.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            )
        }
    }
}

private sealed interface Block {
    data class Paragraph(val raw: String) : Block
    data class Header(val level: Int, val text: String) : Block
    data class Code(val language: String, val code: String) : Block
}

private fun splitMarkdownBlocks(text: String): List<Block> {
    val blocks = mutableListOf<Block>()
    val lines = text.lines()
    var inCodeBlock = false
    var codeLang = ""
    val codeBuilder = StringBuilder()
    val paraBuilder = StringBuilder()

    fun flushPara() {
        val p = paraBuilder.toString().trim()
        if (p.isNotEmpty()) {
            blocks.add(Block.Paragraph(p))
            paraBuilder.clear()
        }
    }

    for (line in lines) {
        if (line.trim().startsWith("```")) {
            if (inCodeBlock) {
                blocks.add(Block.Code(codeLang, codeBuilder.toString().trimEnd()))
                codeBuilder.clear()
                codeLang = ""
                inCodeBlock = false
            } else {
                flushPara()
                inCodeBlock = true
                codeLang = line.trim().removePrefix("```").trim()
            }
            continue
        }

        if (inCodeBlock) {
            codeBuilder.append(line).append("\n")
            continue
        }

        val trimmed = line.trim()
        if (trimmed.startsWith("### ")) {
            flushPara()
            blocks.add(Block.Header(3, trimmed.removePrefix("### ")))
        } else if (trimmed.startsWith("## ")) {
            flushPara()
            blocks.add(Block.Header(2, trimmed.removePrefix("## ")))
        } else if (trimmed.startsWith("# ")) {
            flushPara()
            blocks.add(Block.Header(1, trimmed.removePrefix("# ")))
        } else if (trimmed.isEmpty()) {
            flushPara()
        } else {
            if (paraBuilder.isNotEmpty()) paraBuilder.append("\n")
            paraBuilder.append(line)
        }
    }

    if (inCodeBlock) {
        blocks.add(Block.Code(codeLang, codeBuilder.toString().trimEnd()))
    } else {
        flushPara()
    }

    return blocks
}

private fun parseInlineFormatting(raw: String, baseColor: Color): androidx.compose.ui.text.AnnotatedString {
    return buildAnnotatedString {
        var i = 0
        while (i < raw.length) {
            if (raw.startsWith("**", i)) {
                val end = raw.indexOf("**", i + 2)
                if (end != -1) {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = baseColor)) {
                        append(raw.substring(i + 2, end))
                    }
                    i = end + 2
                    continue
                }
            } else if (raw.startsWith("`", i)) {
                val end = raw.indexOf("`", i + 1)
                if (end != -1) {
                    withStyle(SpanStyle(fontFamily = FontFamily.Monospace, color = CyanAccent, background = Color(0x3306B6D4))) {
                        append(" ${raw.substring(i + 1, end)} ")
                    }
                    i = end + 1
                    continue
                }
            }
            append(raw[i])
            i++
        }
    }
}

fun isUrduScript(str: String): Boolean {
    val urduCount = str.count { char ->
        char in '\u0600'..'\u06FF' || char in '\u0750'..'\u077F' || char in '\uFB50'..'\uFDFF'
    }
    return urduCount > 0 && urduCount >= (str.trim().length / 5).coerceAtLeast(1)
}

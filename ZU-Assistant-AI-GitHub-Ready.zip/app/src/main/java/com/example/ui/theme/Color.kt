package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Futuristic ZU Assistant Palette
val DeepBlack = Color(0xFF070A12)
val MidnightBlue = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF131D33)
val CardBackgroundDark = Color(0xFF1A243B)
val CardBorderDark = Color(0xFF2E3E66)

val VioletPrimary = Color(0xFF8B5CF6)
val VioletNeon = Color(0xFFA855F7)
val CyanAccent = Color(0xFF06B6D4)
val CyanGlow = Color(0xFF22D3EE)
val EmeraldSuccess = Color(0xFF10B981)
val AmberWarning = Color(0xFFF59E0B)
val RoseError = Color(0xFFEF4444)

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextTertiaryDark = Color(0xFF64748B)

// Light Theme Palette
val PureWhite = Color(0xFFFFFFFF)
val SurfaceLight = Color(0xFFF8FAFC)
val CardBackgroundLight = Color(0xFFFFFFFF)
val CardBorderLight = Color(0xFFE2E8F0)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)

// AI Glowing Gradients
val OrbGradient = Brush.radialGradient(
    colors = listOf(
        CyanGlow.copy(alpha = 0.9f),
        VioletNeon.copy(alpha = 0.85f),
        VioletPrimary.copy(alpha = 0.5f),
        Color.Transparent
    )
)

val OrbListeningGradient = Brush.radialGradient(
    colors = listOf(
        CyanGlow.copy(alpha = 0.95f),
        Color(0xFF38BDF8).copy(alpha = 0.8f),
        VioletNeon.copy(alpha = 0.4f),
        Color.Transparent
    )
)

val OrbSpeakingGradient = Brush.radialGradient(
    colors = listOf(
        VioletNeon.copy(alpha = 0.95f),
        Color(0xFFEC4899).copy(alpha = 0.8f),
        CyanGlow.copy(alpha = 0.4f),
        Color.Transparent
    )
)

val PrimaryNeonGradient = Brush.horizontalGradient(
    colors = listOf(VioletPrimary, CyanAccent)
)

val DarkCardGradient = Brush.verticalGradient(
    colors = listOf(CardBackgroundDark, SurfaceDark)
)

package com.example.ui

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.ChatMessageEntity
import com.example.data.local.ChatSessionEntity
import com.example.data.local.NoteEntity
import com.example.data.local.UserPreferences
import com.example.data.remote.GeminiClient
import com.example.data.remote.GeminiContent
import com.example.data.remote.GeminiPart
import com.example.device.BatteryInfo
import com.example.device.DateTimeInfo
import com.example.device.DeviceController
import com.example.domain.IntentResult
import com.example.domain.IntentRouter
import com.example.domain.LanguageType
import com.example.voice.VoiceAssistantManager
import com.example.voice.VoiceState
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class ScreenDestination {
    DASHBOARD,
    VOICE_ASSISTANT,
    CHAT,
    DEVICE_TOOLS,
    PRODUCTIVITY,
    SETTINGS
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        private const val TAG = "MainViewModel"
    }

    private val database = AppDatabase.getDatabase(application)
    val chatDao = database.chatDao()
    val noteDao = database.noteDao()

    val userPreferences = UserPreferences(application)
    val deviceController = DeviceController(application)
    val intentRouter = IntentRouter(deviceController)

    val geminiClient = GeminiClient(
        apiKeyProvider = { userPreferences.customApiKey.value },
        modelProvider = { userPreferences.selectedModel.value }
    )

    // Navigation state
    private val _currentScreen = MutableStateFlow(ScreenDestination.DASHBOARD)
    val currentScreen: StateFlow<ScreenDestination> = _currentScreen.asStateFlow()

    // Active Chat Session
    private val _activeSessionId = MutableStateFlow<Long?>(null)
    val activeSessionId: StateFlow<Long?> = _activeSessionId.asStateFlow()

    private val _currentMessages = MutableStateFlow<List<ChatMessageEntity>>(emptyList())
    val currentMessages: StateFlow<List<ChatMessageEntity>> = _currentMessages.asStateFlow()

    val allSessions: StateFlow<List<ChatSessionEntity>> = chatDao.getAllSessions()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val allNotes: StateFlow<List<NoteEntity>> = noteDao.getAllNotes()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // Generation state
    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private var activeGenerationJob: Job? = null

    // Real-time device telemetry
    private val _batteryInfo = MutableStateFlow(deviceController.getBatteryStatus())
    val batteryInfo: StateFlow<BatteryInfo> = _batteryInfo.asStateFlow()

    private val _dateTimeInfo = MutableStateFlow(deviceController.getCurrentDateTime())
    val dateTimeInfo: StateFlow<DateTimeInfo> = _dateTimeInfo.asStateFlow()

    private val _isTorchOn = MutableStateFlow(false)
    val isTorchOn: StateFlow<Boolean> = _isTorchOn.asStateFlow()

    // Last spoken/action feedback for UI snackbar or status badge
    private val _lastActionFeedback = MutableStateFlow<String?>(null)
    val lastActionFeedback: StateFlow<String?> = _lastActionFeedback.asStateFlow()

    // Voice assistant manager
    val voiceAssistantManager: VoiceAssistantManager by lazy {
        VoiceAssistantManager(
            context = getApplication(),
            onSpeechRecognized = { speechText ->
                handleUserInput(speechText, fromVoice = true)
            }
        )
    }

    val voiceState: StateFlow<VoiceState> get() = voiceAssistantManager.voiceState
    val rmsDb: StateFlow<Float> get() = voiceAssistantManager.rmsDb

    init {
        refreshTelemetry()
        // Initialize default chat session if none exists
        viewModelScope.launch {
            val sessions = chatDao.getAllSessions().stateIn(viewModelScope).value
            if (sessions.isNotEmpty()) {
                selectSession(sessions.first().id)
            } else {
                createNewSession("Welcome to ZU Assistant")
            }
        }
    }

    fun navigateTo(destination: ScreenDestination) {
        _currentScreen.value = destination
    }

    fun refreshTelemetry() {
        _batteryInfo.value = deviceController.getBatteryStatus()
        _dateTimeInfo.value = deviceController.getCurrentDateTime()
        _isTorchOn.value = deviceController.isTorchActive()
    }

    fun toggleTorch() {
        val (success, msg) = deviceController.toggleTorch()
        _isTorchOn.value = deviceController.isTorchActive()
        _lastActionFeedback.value = msg
    }

    fun selectSession(sessionId: Long) {
        _activeSessionId.value = sessionId
        viewModelScope.launch {
            chatDao.getMessagesForSession(sessionId).collect { list ->
                _currentMessages.value = list
            }
        }
    }

    fun createNewSession(title: String = "New Chat") {
        viewModelScope.launch {
            val id = chatDao.insertSession(ChatSessionEntity(title = title))
            selectSession(id)
            // Add friendly greeting message
            val greeting = "السلام علیکم! میں آپ کا زیڈ یو اسسٹنٹ ہوں۔ میں اردو، رومن اردو اور انگلش سمجھتا ہوں۔ آپ مجھ سے فون کنٹرولز (جیسے ٹارچ، بیٹری، واٹس ایپ) اور کوئی بھی سوال پوچھ سکتے ہیں۔\n\nHow can I help you today?"
            chatDao.insertMessage(
                ChatMessageEntity(
                    sessionId = id,
                    sender = "model",
                    content = greeting,
                    language = "urdu"
                )
            )
        }
    }

    fun deleteSession(sessionId: Long) {
        viewModelScope.launch {
            chatDao.deleteSessionById(sessionId)
            if (_activeSessionId.value == sessionId) {
                val remaining = chatDao.getAllSessions().stateIn(viewModelScope).value
                if (remaining.isNotEmpty()) {
                    selectSession(remaining.first().id)
                } else {
                    createNewSession()
                }
            }
        }
    }

    fun renameSession(sessionId: Long, newTitle: String) {
        viewModelScope.launch {
            chatDao.updateSession(
                ChatSessionEntity(
                    id = sessionId,
                    title = newTitle,
                    lastMessageAt = System.currentTimeMillis()
                )
            )
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            chatDao.clearAllHistory()
            createNewSession("New Chat")
        }
    }

    /**
     * Core orchestrator: processes voice or text commands
     */
    fun handleUserInput(rawText: String, fromVoice: Boolean = false) {
        if (rawText.isBlank()) return
        val currentId = _activeSessionId.value ?: return

        // 1. Post user message to UI immediately
        viewModelScope.launch {
            chatDao.insertMessage(
                ChatMessageEntity(
                    sessionId = currentId,
                    sender = "user",
                    content = rawText
                )
            )
        }

        // 2. Intelligent Command Routing
        when (val result = intentRouter.route(rawText)) {
            is IntentResult.LocalAction -> {
                handleLocalActionResult(result, currentId, fromVoice)
            }
            is IntentResult.AiQuery -> {
                executeAiQuery(result.prompt, currentId, fromVoice)
            }
        }
    }

    private fun handleLocalActionResult(
        action: IntentResult.LocalAction,
        sessionId: Long,
        fromVoice: Boolean
    ) {
        refreshTelemetry()
        val feedback = when (intentRouter.detectLanguage(action.feedbackRomanUrdu)) {
            LanguageType.URDU_SCRIPT -> action.feedbackUrdu
            LanguageType.ROMAN_URDU -> action.feedbackRomanUrdu
            else -> "${action.feedbackEnglish}\n${action.feedbackUrdu}"
        }

        _lastActionFeedback.value = action.feedbackEnglish

        viewModelScope.launch {
            chatDao.insertMessage(
                ChatMessageEntity(
                    sessionId = sessionId,
                    sender = "model",
                    content = feedback
                )
            )
            chatDao.updateSession(
                ChatSessionEntity(
                    id = sessionId,
                    title = action.actionType.replace("_", " "),
                    lastMessageAt = System.currentTimeMillis()
                )
            )
        }

        if (fromVoice) {
            val spokenText = if (action.feedbackRomanUrdu.isNotEmpty()) action.feedbackRomanUrdu else action.feedbackEnglish
            voiceAssistantManager.speak(spokenText, isUrdu = false)
        }
    }

    private fun executeAiQuery(prompt: String, sessionId: Long, fromVoice: Boolean) {
        activeGenerationJob?.cancel()
        _isGenerating.value = true

        activeGenerationJob = viewModelScope.launch {
            // Build conversation history for multi-turn context
            val historyEntities = chatDao.getMessagesListForSession(sessionId)
            val geminiHistory = historyEntities.map { entity ->
                GeminiContent(
                    role = if (entity.sender == "user") "user" else "model",
                    parts = listOf(GeminiPart(text = entity.content))
                )
            }

            val accumulatedResponse = StringBuilder()
            val tempMessageId = chatDao.insertMessage(
                ChatMessageEntity(
                    sessionId = sessionId,
                    sender = "model",
                    content = "..."
                )
            )

            try {
                geminiClient.streamGenerateContent(geminiHistory, prompt).collect { chunk ->
                    accumulatedResponse.append(chunk)
                    chatDao.insertMessage(
                        ChatMessageEntity(
                            id = tempMessageId,
                            sessionId = sessionId,
                            sender = "model",
                            content = accumulatedResponse.toString()
                        )
                    )
                }

                val finalContent = accumulatedResponse.toString().ifEmpty { "Model returned an empty response." }
                chatDao.updateSession(
                    ChatSessionEntity(
                        id = sessionId,
                        title = prompt.take(30),
                        lastMessageAt = System.currentTimeMillis()
                    )
                )

                if (fromVoice) {
                    val isUrdu = intentRouter.detectLanguage(finalContent) == LanguageType.URDU_SCRIPT
                    voiceAssistantManager.speak(finalContent.take(300), isUrdu = isUrdu)
                }
            } catch (e: Exception) {
                Log.e(TAG, "AI generation error", e)
                chatDao.insertMessage(
                    ChatMessageEntity(
                        id = tempMessageId,
                        sessionId = sessionId,
                        sender = "model",
                        content = "❌ Generation failed: ${e.localizedMessage ?: "Unknown error"}",
                        isError = true
                    )
                )
            } finally {
                _isGenerating.value = false
            }
        }
    }

    fun stopGeneration() {
        activeGenerationJob?.cancel()
        _isGenerating.value = false
    }

    fun regenerateLastMessage() {
        val currentId = _activeSessionId.value ?: return
        viewModelScope.launch {
            val list = chatDao.getMessagesListForSession(currentId)
            val lastUserMsg = list.lastOrNull { it.sender == "user" }
            if (lastUserMsg != null) {
                executeAiQuery(lastUserMsg.content, currentId, fromVoice = false)
            }
        }
    }

    // Notes & To-dos actions
    fun addNote(title: String, content: String, isTodo: Boolean = false) {
        viewModelScope.launch {
            noteDao.insertNote(
                NoteEntity(
                    title = title,
                    content = content,
                    isTodo = isTodo
                )
            )
        }
    }

    fun toggleTodo(note: NoteEntity) {
        viewModelScope.launch {
            noteDao.updateNote(note.copy(isCompleted = !note.isCompleted))
        }
    }

    fun deleteNote(note: NoteEntity) {
        viewModelScope.launch {
            noteDao.deleteNote(note)
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceAssistantManager.destroy()
    }
}

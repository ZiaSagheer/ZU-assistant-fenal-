package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material.icons.filled.Summarize
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SecondaryTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.NoteEntity
import com.example.ui.MainViewModel
import com.example.ui.ScreenDestination
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.VioletNeon
import com.example.ui.theme.VioletPrimary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductivityScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val notes by viewModel.allNotes.collectAsState()

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabTitles = listOf("Notes & Tasks", "Calculator", "Unit Converter", "AI Tools")

    // Add note dialog state
    var showAddNoteDialog by remember { mutableStateOf(false) }
    var noteTitleInput by remember { mutableStateOf("") }
    var noteContentInput by remember { mutableStateOf("") }
    var isTodoCheck by remember { mutableStateOf(false) }

    // Search query
    var searchQuery by remember { mutableStateOf("") }

    val filteredNotes = remember(notes, searchQuery) {
        if (searchQuery.isBlank()) notes
        else notes.filter { it.title.contains(searchQuery, ignoreCase = true) || it.content.contains(searchQuery, ignoreCase = true) }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "PRODUCTIVITY & TOOLS",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = CyanAccent
        )
        Text(
            text = "نوٹس، ٹاسکس اور روزمرہ ٹولز",
            style = MaterialTheme.typography.labelSmall,
            color = VioletNeon
        )

        Spacer(modifier = Modifier.height(12.dp))

        SecondaryTabRow(
            selectedTabIndex = selectedTabIndex,
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ) {
            tabTitles.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTabIndex == index,
                    onClick = { selectedTabIndex = index },
                    text = { Text(title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        when (selectedTabIndex) {
            0 -> {
                // Notes & To-dos
                NotesTab(
                    notes = filteredNotes,
                    searchQuery = searchQuery,
                    onSearchChange = { searchQuery = it },
                    onAddClick = { showAddNoteDialog = true },
                    onToggleTodo = { viewModel.toggleTodo(it) },
                    onDelete = { viewModel.deleteNote(it) }
                )
            }
            1 -> {
                // Calculator Tab
                CalculatorTab()
            }
            2 -> {
                // Unit Converter Tab
                UnitConverterTab()
            }
            3 -> {
                // AI Assist Tools (Summarizer, Translator, Caption)
                AiAssistToolsTab(
                    onTriggerAiPrompt = { prompt ->
                        viewModel.handleUserInput(prompt)
                        viewModel.navigateTo(ScreenDestination.CHAT)
                    }
                )
            }
        }
    }

    // Add Note / Task Dialog
    if (showAddNoteDialog) {
        AlertDialog(
            onDismissRequest = { showAddNoteDialog = false },
            title = { Text(if (isTodoCheck) "Add New Task" else "Add New Note") },
            text = {
                Column {
                    OutlinedTextField(
                        value = noteTitleInput,
                        onValueChange = { noteTitleInput = it },
                        label = { Text("Title (عنوان)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = noteContentInput,
                        onValueChange = { noteContentInput = it },
                        label = { Text("Description / Details") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 4
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { isTodoCheck = !isTodoCheck }
                    ) {
                        Checkbox(
                            checked = isTodoCheck,
                            onCheckedChange = { isTodoCheck = it }
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Create as To-Do Task item")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (noteTitleInput.isNotBlank()) {
                            viewModel.addNote(noteTitleInput, noteContentInput, isTodo = isTodoCheck)
                            noteTitleInput = ""
                            noteContentInput = ""
                            isTodoCheck = false
                            showAddNoteDialog = false
                        }
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddNoteDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun NotesTab(
    notes: List<NoteEntity>,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    onAddClick: () -> Unit,
    onToggleTodo: (NoteEntity) -> Unit,
    onDelete: (NoteEntity) -> Unit
) {
    val context = LocalContext.current

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                placeholder = { Text("Search notes...", fontSize = 13.sp) },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = onAddClick,
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add")
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (notes.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No notes or tasks saved yet.\nTap '+ Add' to save local notes or to-dos!",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(notes, key = { it.id }) { note ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (note.isTodo) {
                                IconButton(onClick = { onToggleTodo(note) }, modifier = Modifier.size(28.dp)) {
                                    Icon(
                                        imageVector = if (note.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                        contentDescription = "Toggle status",
                                        tint = if (note.isCompleted) EmeraldSuccess else CyanAccent
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = note.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    textDecoration = if (note.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                                )
                                if (note.content.isNotEmpty()) {
                                    Text(
                                        text = note.content,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(note.timestamp)),
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            IconButton(
                                onClick = {
                                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    cm.setPrimaryClip(ClipData.newPlainText("note", "${note.title}\n${note.content}"))
                                    Toast.makeText(context, "Note copied", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy", modifier = Modifier.size(16.dp))
                            }

                            IconButton(
                                onClick = { onDelete(note) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFEF4444), modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CalculatorTab() {
    var display by remember { mutableStateOf("0") }
    var expression by remember { mutableStateOf("") }

    val buttons = listOf(
        listOf("C", "(", ")", "/"),
        listOf("7", "8", "9", "*"),
        listOf("4", "5", "6", "-"),
        listOf("1", "2", "3", "+"),
        listOf("0", ".", "DEL", "=")
    )

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = expression,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = display,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = CyanAccent
                )
            }
        }

        // Keypad Grid
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            buttons.forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    row.forEach { label ->
                        val isOp = label in listOf("/", "*", "-", "+", "=")
                        Button(
                            onClick = {
                                when (label) {
                                    "C" -> {
                                        display = "0"
                                        expression = ""
                                    }
                                    "DEL" -> {
                                        if (display.length > 1) display = display.dropLast(1)
                                        else display = "0"
                                    }
                                    "=" -> {
                                        val fullExpr = expression + display
                                        val result = evaluateSimpleExpression(fullExpr)
                                        expression = "$fullExpr = "
                                        display = result
                                    }
                                    in listOf("+", "-", "*", "/") -> {
                                        expression = "$display $label "
                                        display = "0"
                                    }
                                    else -> {
                                        if (display == "0") display = label
                                        else display += label
                                    }
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (label == "=") VioletPrimary else if (isOp) CyanAccent.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surfaceVariant
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                        ) {
                            Text(
                                text = label,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (label == "=") Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun evaluateSimpleExpression(expr: String): String {
    return try {
        val parts = expr.trim().split(" ")
        if (parts.size >= 3) {
            val n1 = parts[0].toDoubleOrNull() ?: return "Error"
            val op = parts[1]
            val n2 = parts[2].toDoubleOrNull() ?: return "Error"
            val res = when (op) {
                "+" -> n1 + n2
                "-" -> n1 - n2
                "*" -> n1 * n2
                "/" -> if (n2 != 0.0) n1 / n2 else return "Div by 0"
                else -> return "Error"
            }
            if (res % 1.0 == 0.0) res.toInt().toString() else "%.3f".format(res)
        } else {
            expr
        }
    } catch (_: Exception) {
        "Error"
    }
}

@Composable
private fun UnitConverterTab() {
    var inputValue by remember { mutableStateOf("1") }
    var conversionType by remember { mutableStateOf("Length") }

    val types = listOf("Length", "Weight", "Temperature")

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            types.forEach { t ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (conversionType == t) CyanAccent else MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.clickable { conversionType = t }
                ) {
                    Text(
                        text = t,
                        color = if (conversionType == t) Color.Black else MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
        }

        OutlinedTextField(
            value = inputValue,
            onValueChange = { inputValue = it },
            label = { Text("Input Value") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        val v = inputValue.toDoubleOrNull() ?: 0.0

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                when (conversionType) {
                    "Length" -> {
                        Text("• $v Meters = ${(v * 3.28084).formatDecimal()} Feet", fontWeight = FontWeight.SemiBold)
                        Text("• $v Kilometers = ${(v * 0.621371).formatDecimal()} Miles", fontWeight = FontWeight.SemiBold)
                        Text("• $v Inches = ${(v * 2.54).formatDecimal()} Centimeters", fontWeight = FontWeight.SemiBold)
                    }
                    "Weight" -> {
                        Text("• $v Kilograms = ${(v * 2.20462).formatDecimal()} Pounds (lbs)", fontWeight = FontWeight.SemiBold)
                        Text("• $v Grams = ${(v * 0.035274).formatDecimal()} Ounces", fontWeight = FontWeight.SemiBold)
                    }
                    "Temperature" -> {
                        val f = (v * 9 / 5) + 32
                        val c = (v - 32) * 5 / 9
                        Text("• $v°C = ${f.formatDecimal()}°F", fontWeight = FontWeight.SemiBold)
                        Text("• $v°F = ${c.formatDecimal()}°C", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

private fun Double.formatDecimal(): String = if (this % 1.0 == 0.0) this.toInt().toString() else "%.2f".format(this)

@Composable
private fun AiAssistToolsTab(onTriggerAiPrompt: (String) -> Unit) {
    var rawTextInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Enter text or topic to analyze with AI:",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        OutlinedTextField(
            value = rawTextInput,
            onValueChange = { rawTextInput = it },
            placeholder = { Text("Paste article, message, or notes here...") },
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp),
            maxLines = 6
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    if (rawTextInput.isNotBlank()) {
                        onTriggerAiPrompt("Summarize this text in 3 concise bullet points with Urdu translation:\n\n$rawTextInput")
                    }
                },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Summarize, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Summarize", fontSize = 11.sp)
            }

            Button(
                onClick = {
                    if (rawTextInput.isNotBlank()) {
                        onTriggerAiPrompt("Translate this text accurately into natural Urdu (اردو) and Roman Urdu:\n\n$rawTextInput")
                    }
                },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Translate, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("To Urdu", fontSize = 11.sp)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    if (rawTextInput.isNotBlank()) {
                        onTriggerAiPrompt("Translate this Urdu or Roman Urdu text into professional, polished English:\n\n$rawTextInput")
                    }
                },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Translate, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("To English", fontSize = 11.sp)
            }

            Button(
                onClick = {
                    if (rawTextInput.isNotBlank()) {
                        onTriggerAiPrompt("Write 3 creative social media captions with hashtags and Roman Urdu versions for:\n\n$rawTextInput")
                    }
                },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.EditNote, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Caption Writer", fontSize = 11.sp)
            }
        }
    }
}

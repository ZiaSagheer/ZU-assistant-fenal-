package com.example.voice

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

sealed interface VoiceState {
    data object Idle : VoiceState
    data class Listening(
        val language: String = "ur-PK",
        val partialTranscript: String = ""
    ) : VoiceState
    data class Processing(
        val query: String = ""
    ) : VoiceState
    data class Speaking(
        val text: String
    ) : VoiceState
    data class Error(
        val message: String,
        val canRetry: Boolean = true
    ) : VoiceState
}

/**
 * Built-in Speech-to-Text and Text-to-Speech manager for ZU Assistant.
 * Fully supports Urdu (ur-PK), Roman Urdu, and English (en-US).
 * Dispatches all recognizer calls on the Android Main/UI thread.
 */
class VoiceAssistantManager(
    private val context: Context,
    private val onSpeechRecognized: (String) -> Unit
) : TextToSpeech.OnInitListener {

    companion object {
        private const val TAG = "VoiceAssistantManager"
        private const val UTTERANCE_ID_SPEAK = "zu_assistant_utterance"

        const val LANG_URDU = "ur-PK"
        const val LANG_ENGLISH = "en-US"
        const val LANG_AUTO = "auto"
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    private val _voiceState = MutableStateFlow<VoiceState>(VoiceState.Idle)
    val voiceState: StateFlow<VoiceState> = _voiceState.asStateFlow()

    private val _rmsDb = MutableStateFlow(0f)
    val rmsDb: StateFlow<Float> = _rmsDb.asStateFlow()

    private val _selectedLanguage = MutableStateFlow(LANG_AUTO)
    val selectedLanguage: StateFlow<String> = _selectedLanguage.asStateFlow()

    private val _liveTranscript = MutableStateFlow("")
    val liveTranscript: StateFlow<String> = _liveTranscript.asStateFlow()

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady = false

    private var currentSpeechRate: Float = 1.0f
    private var currentSpeechPitch: Float = 1.0f

    init {
        initTts()
    }

    private fun initTts() {
        try {
            textToSpeech = TextToSpeech(context.applicationContext, this)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to init TextToSpeech", e)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            // Try Urdu language locale first; fall back to English if Urdu TTS data not installed
            val urduLocale = Locale("ur", "PK")
            val urduResult = textToSpeech?.setLanguage(urduLocale)
            if (urduResult == TextToSpeech.LANG_MISSING_DATA || urduResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                textToSpeech?.setLanguage(Locale.US)
            }
            textToSpeech?.setSpeechRate(currentSpeechRate)
            textToSpeech?.setPitch(currentSpeechPitch)

            textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    // Speaking state already updated
                }

                override fun onDone(utteranceId: String?) {
                    _voiceState.value = VoiceState.Idle
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _voiceState.value = VoiceState.Idle
                }
            })
        } else {
            Log.e(TAG, "TextToSpeech init failed with status: $status")
        }
    }

    fun updateTtsSettings(rate: Float, pitch: Float) {
        currentSpeechRate = rate
        currentSpeechPitch = pitch
        textToSpeech?.setSpeechRate(rate)
        textToSpeech?.setPitch(pitch)
    }

    fun setSpeechLanguage(langCode: String) {
        _selectedLanguage.value = langCode
    }

    fun isPermissionGranted(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun isSpeechRecognitionAvailable(): Boolean {
        return SpeechRecognizer.isRecognitionAvailable(context)
    }

    /**
     * Starts listening using Android's native SpeechRecognizer.
     * Enforces execution on the main Looper thread.
     */
    fun startListening(preferredLangCode: String? = null) {
        mainHandler.post {
            stopSpeaking()
            vibrate(50)

            if (!isPermissionGranted()) {
                _voiceState.value = VoiceState.Error(
                    message = "Microphone permission required (مائیکروفون کی اجازت درکار ہے)",
                    canRetry = true
                )
                return@post
            }

            if (!isSpeechRecognitionAvailable()) {
                _voiceState.value = VoiceState.Error(
                    message = "Speech recognition service is not available on this device (آواز پہچاننے کی سروس دستیاب نہیں)",
                    canRetry = false
                )
                return@post
            }

            val targetLang = preferredLangCode ?: _selectedLanguage.value
            _liveTranscript.value = ""

            try {
                // Destroy existing recognizer before instantiating a clean instance
                speechRecognizer?.let {
                    try {
                        it.stopListening()
                        it.cancel()
                        it.destroy()
                    } catch (e: Exception) {
                        Log.w(TAG, "Error resetting previous speech recognizer", e)
                    }
                }

                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {
                            Log.d(TAG, "onReadyForSpeech")
                            _voiceState.value = VoiceState.Listening(
                                language = targetLang,
                                partialTranscript = ""
                            )
                        }

                        override fun onBeginningOfSpeech() {
                            Log.d(TAG, "onBeginningOfSpeech")
                            _voiceState.value = VoiceState.Listening(
                                language = targetLang,
                                partialTranscript = _liveTranscript.value
                            )
                        }

                        override fun onRmsChanged(rmsdB: Float) {
                            _rmsDb.value = rmsdB.coerceAtLeast(0f)
                        }

                        override fun onBufferReceived(buffer: ByteArray?) {}

                        override fun onEndOfSpeech() {
                            Log.d(TAG, "onEndOfSpeech")
                            _voiceState.value = VoiceState.Processing(
                                query = _liveTranscript.value
                            )
                        }

                        override fun onError(error: Int) {
                            val message = when (error) {
                                SpeechRecognizer.ERROR_NO_MATCH ->
                                    "No speech detected. Please speak clearly. (کوئی آواز نہیں ملی، دوبارہ بولیں)"
                                SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                                    "Speech timed out. Please tap and speak again. (بولنے کا وقت ختم ہو گیا)"
                                SpeechRecognizer.ERROR_AUDIO ->
                                    "Audio recording error. Please check your mic."
                                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                                    "Microphone permission required. (مائیکروفون کی اجازت درکار ہے)"
                                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                                    "Network error during speech recognition. (انٹرنیٹ کنکشن درکار ہے)"
                                SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                                    "Speech recognizer is busy. Resetting..."
                                SpeechRecognizer.ERROR_SERVER ->
                                    "Voice server error. Please try again in a moment."
                                SpeechRecognizer.ERROR_CLIENT ->
                                    "Speech recognition client error."
                                else -> "Speech recognition error ($error)."
                            }
                            Log.w(TAG, "Speech recognition error code: $error -> $message")
                            _rmsDb.value = 0f
                            _voiceState.value = VoiceState.Error(message = message, canRetry = true)
                        }

                        override fun onResults(results: Bundle?) {
                            _rmsDb.value = 0f
                            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val recognizedText = matches?.firstOrNull()?.trim().orEmpty()
                            Log.d(TAG, "onResults recognized: $recognizedText")

                            if (recognizedText.isNotEmpty()) {
                                _liveTranscript.value = recognizedText
                                _voiceState.value = VoiceState.Processing(query = recognizedText)
                                onSpeechRecognized(recognizedText)
                            } else {
                                _voiceState.value = VoiceState.Idle
                            }
                        }

                        override fun onPartialResults(partialResults: Bundle?) {
                            val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val partial = matches?.firstOrNull()?.trim().orEmpty()
                            if (partial.isNotEmpty()) {
                                _liveTranscript.value = partial
                                _voiceState.value = VoiceState.Listening(
                                    language = targetLang,
                                    partialTranscript = partial
                                )
                            }
                        }

                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                }

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)

                    when (targetLang) {
                        LANG_ENGLISH -> {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-US")
                            putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("en-US", "en-GB"))
                        }
                        LANG_URDU -> {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ur-PK")
                            putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("ur-PK", "ur", "en-US"))
                        }
                        else -> {
                            // Auto / Mixed mode: prioritize Urdu and English
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ur-PK")
                            putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("ur-PK", "en-US", "ur"))
                        }
                    }
                }

                speechRecognizer?.startListening(intent)
                _voiceState.value = VoiceState.Listening(language = targetLang, partialTranscript = "")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to start listening", e)
                _voiceState.value = VoiceState.Error(
                    message = "Could not activate microphone: ${e.localizedMessage ?: "Unknown error"}",
                    canRetry = true
                )
            }
        }
    }

    fun stopListening() {
        mainHandler.post {
            try {
                speechRecognizer?.stopListening()
            } catch (e: Exception) {
                Log.w(TAG, "Error stopping speech recognizer", e)
            }
            if (_voiceState.value is VoiceState.Listening) {
                _voiceState.value = VoiceState.Idle
            }
            _rmsDb.value = 0f
        }
    }

    fun cancelListening() {
        mainHandler.post {
            try {
                speechRecognizer?.cancel()
            } catch (e: Exception) {
                Log.w(TAG, "Error canceling speech recognizer", e)
            }
            _voiceState.value = VoiceState.Idle
            _rmsDb.value = 0f
        }
    }

    fun speak(text: String, isUrdu: Boolean = false) {
        if (!isTtsReady || textToSpeech == null) {
            Log.w(TAG, "TextToSpeech not ready yet")
            return
        }

        stopSpeaking()
        _voiceState.value = VoiceState.Speaking(text)

        // Sanitize markdown and emojis for speech
        val cleaned = text
            .replace(Regex("[#*_`\\[\\]()]"), "")
            .replace(Regex("https?://\\S+"), "link")
            .trim()

        if (isUrdu) {
            val urduLocale = Locale("ur", "PK")
            val result = textToSpeech?.setLanguage(urduLocale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                textToSpeech?.setLanguage(Locale.US)
            }
        } else {
            textToSpeech?.setLanguage(Locale.US)
        }

        textToSpeech?.speak(cleaned, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID_SPEAK)
    }

    fun stopSpeaking() {
        if (textToSpeech?.isSpeaking == true) {
            textToSpeech?.stop()
        }
        if (_voiceState.value is VoiceState.Speaking) {
            _voiceState.value = VoiceState.Idle
        }
    }

    private fun vibrate(durationMillis: Long) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(durationMillis, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                @Suppress("DEPRECATION")
                v?.vibrate(durationMillis)
            }
        } catch (_: Exception) {}
    }

    fun destroy() {
        mainHandler.post {
            try {
                speechRecognizer?.stopListening()
                speechRecognizer?.cancel()
                speechRecognizer?.destroy()
                speechRecognizer = null
            } catch (e: Exception) {
                Log.w(TAG, "Error destroying SpeechRecognizer", e)
            }
        }
        try {
            textToSpeech?.stop()
            textToSpeech?.shutdown()
            textToSpeech = null
        } catch (e: Exception) {
            Log.w(TAG, "Error destroying TextToSpeech", e)
        }
    }
}
